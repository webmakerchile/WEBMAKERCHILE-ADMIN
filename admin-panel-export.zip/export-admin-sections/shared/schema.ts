import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, timestamp, pgEnum, serial, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Re-export auth models (users and sessions tables from Replit Auth)
export * from "./models/auth";
// Re-export chat models for Gemini integration
export * from "./models/chat";
// Re-export CMS pages models
export * from "./models/pages";
import { users } from "./models/auth";

// Enums
export const proposalStatusEnum = pgEnum("proposal_status", ["DRAFT", "SENT", "VIEWED", "APPROVED", "REJECTED", "EXPIRED"]);
export const projectStatusEnum = pgEnum("project_status", ["MOCKUP", "DEVELOPMENT", "QA", "DELIVERY", "COMPLETED"]);
export const paymentModalityEnum = pgEnum("payment_modality", ["STANDARD", "MILESTONES", "FULL_ADVANCE", "INSTALLMENTS", "CUSTOM"]);
export const maintenanceTypeEnum = pgEnum("maintenance_type", ["NONE", "TO_BE_DEFINED", "CUSTOM"]);
export const bookingStatusEnum = pgEnum("booking_status", ["PENDING_PAYMENT", "CONFIRMED", "CANCELLED"]);
export const expenseCategoryEnum = pgEnum("expense_category", ["FACEBOOK_ADS", "TIKTOK_ADS", "SOFTWARE", "OTHER"]);

// Clients table
export const clients = pgTable("clients", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyName: text("company_name").notNull(),
  rut: text("rut"),
  billingRut: text("billing_rut"),
  contactName: text("contact_name"),
  contactEmail: text("contact_email"),
  contactPhone: text("contact_phone"),
  address: text("address"),
  closerId: varchar("closer_id").references(() => developers.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const clientsRelations = relations(clients, ({ many }) => ({
  proposals: many(proposals),
  projects: many(projects),
}));

// Services catalog
export const services = pgTable("services", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  basePrice: integer("base_price").notNull(),
  costPrice: integer("cost_price").default(0).notNull(),
  isCustomizable: integer("is_customizable").default(0),
});

// Proposals
export const proposals = pgTable("proposals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  clientId: varchar("client_id").references(() => clients.id).notNull(),
  status: proposalStatusEnum("status").default("DRAFT").notNull(),
  tokenUrl: text("token_url").unique(),
  subtotal: integer("subtotal").default(0).notNull(),
  iva: integer("iva").default(0).notNull(),
  total: integer("total").default(0).notNull(),
  hasIVA: integer("has_iva").default(1).notNull(),
  paymentModality: paymentModalityEnum("payment_modality").default("STANDARD").notNull(),
  installmentCount: integer("installment_count").default(3),
  customPaymentTerms: text("custom_payment_terms"),
  maintenanceType: maintenanceTypeEnum("maintenance_type").default("NONE"),
  monthlyMaintenance: integer("monthly_maintenance").default(0).notNull(),
  discount: integer("discount").default(0).notNull(),
  couponId: varchar("coupon_id"),
  notes: text("notes"),
  validUntil: timestamp("valid_until"),
  includeContract: integer("include_contract").default(1).notNull(),
  closerId: varchar("closer_id").references(() => developers.id),
  marginPercent: integer("margin_percent").default(0).notNull(),
  marginTier: text("margin_tier").default("NONE").notNull(),
  closerCommissionRate: integer("closer_commission_rate").default(0).notNull(),
  closerCommission: integer("closer_commission").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const proposalsRelations = relations(proposals, ({ one, many }) => ({
  client: one(clients, {
    fields: [proposals.clientId],
    references: [clients.id],
  }),
  items: many(proposalItems),
  project: one(projects),
}));

// Proposal Items
export const proposalItems = pgTable("proposal_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  proposalId: varchar("proposal_id").references(() => proposals.id).notNull(),
  serviceId: varchar("service_id").references(() => services.id),
  name: text("name").notNull(),
  description: text("description"),
  quantity: integer("quantity").default(1).notNull(),
  unitPrice: integer("unit_price").notNull(),
  total: integer("total").notNull(),
});

export const proposalItemsRelations = relations(proposalItems, ({ one }) => ({
  proposal: one(proposals, {
    fields: [proposalItems.proposalId],
    references: [proposals.id],
  }),
  service: one(services, {
    fields: [proposalItems.serviceId],
    references: [services.id],
  }),
}));

// Developers (collaborators who manage projects without seeing prices)
export const developers = pgTable("developers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").unique().notNull(),
  passwordHash: text("password_hash").notNull(),
  name: text("name").notNull(),
  role: text("role").default("developer").notNull(),
  salary: integer("salary").default(0).notNull(),
  isActive: integer("is_active").default(1).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertDeveloperSchema = createInsertSchema(developers).omit({ id: true, createdAt: true });
export type InsertDeveloper = z.infer<typeof insertDeveloperSchema>;
export type Developer = typeof developers.$inferSelect;

export const laborContractStatusEnum = pgEnum("labor_contract_status", ["DRAFT", "SENT", "SIGNED"]);

export const laborContracts = pgTable("labor_contracts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  developerId: varchar("developer_id").references(() => developers.id).notNull(),
  tokenUrl: text("token_url").unique().notNull(),
  status: laborContractStatusEnum("status").default("DRAFT").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  signedAt: timestamp("signed_at"),
  signedByName: text("signed_by_name"),
  signedByEmail: text("signed_by_email"),
  signedByIp: text("signed_by_ip"),
  signatureType: text("labor_signature_type"),
  signatureData: text("labor_signature_data"),
  signatureImageUrl: text("labor_signature_image_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type LaborContract = typeof laborContracts.$inferSelect;

// Projects
export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  proposalId: varchar("proposal_id").references(() => proposals.id),
  clientId: varchar("client_id").references(() => clients.id).notNull(),
  name: text("name").notNull(),
  status: projectStatusEnum("status").default("MOCKUP").notNull(),
  repositoryUrl: text("repository_url"),
  totalValue: integer("total_value").default(0).notNull(),
  monthlyMaintenance: integer("monthly_maintenance").default(0).notNull(),
  assignedDeveloperId: varchar("assigned_developer_id").references(() => developers.id),
  developerPayment: integer("developer_payment").default(0).notNull(),
  aiCostBudget: integer("ai_cost_budget").default(0).notNull(),
  deadlineDays: integer("deadline_days").default(0).notNull(),
  deadlineStartDate: timestamp("deadline_start_date"),
  driveFolderUrl: text("drive_folder_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const projectsRelations = relations(projects, ({ one, many }) => ({
  proposal: one(proposals, {
    fields: [projects.proposalId],
    references: [proposals.id],
  }),
  client: one(clients, {
    fields: [projects.clientId],
    references: [clients.id],
  }),
  developer: one(developers, {
    fields: [projects.assignedDeveloperId],
    references: [developers.id],
  }),
  tasks: many(tasks),
}));

// Tasks
export const tasks = pgTable("tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => projects.id).notNull(),
  assignedTo: varchar("assigned_to").references(() => users.id),
  proposalItemId: varchar("proposal_item_id").references(() => proposalItems.id),
  title: text("title").notNull(),
  description: text("description"),
  status: text("status").default("pending").notNull(),
  phase: projectStatusEnum("phase").default("MOCKUP").notNull(),
  weight: integer("weight").default(1).notNull(),
  visibleToClient: integer("visible_to_client").default(1).notNull(),
  freelancerCost: integer("freelancer_cost").default(0),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const tasksRelations = relations(tasks, ({ one }) => ({
  project: one(projects, {
    fields: [tasks.projectId],
    references: [projects.id],
  }),
  assignee: one(users, {
    fields: [tasks.assignedTo],
    references: [users.id],
  }),
}));

// Project Progress Log (Bitacora) - enhanced with phase and media support
export const projectLogs = pgTable("project_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => projects.id).notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  phase: projectStatusEnum("phase").default("MOCKUP").notNull(),
  imageUrls: text("image_urls").array(),
  videoUrls: text("video_urls").array(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const projectLogsRelations = relations(projectLogs, ({ one }) => ({
  project: one(projects, {
    fields: [projectLogs.projectId],
    references: [projects.id],
  }),
}));

// Availability Slots for Calendar
export const availabilitySlots = pgTable("availability_slots", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  dayOfWeek: integer("day_of_week").notNull(),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  isActive: integer("is_active").default(1).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Calendar Blocked Weeks
export const blockedWeeks = pgTable("blocked_weeks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  weekStart: timestamp("week_start").notNull(),
  weekEnd: timestamp("week_end").notNull(),
  reason: text("reason"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Bookings (Pay-to-Meet)
export const bookings = pgTable("bookings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  clientName: text("client_name").notNull(),
  clientEmail: text("client_email").notNull(),
  additionalEmails: text("additional_emails"),
  clientPhone: text("client_phone"),
  date: timestamp("date").notNull(),
  status: bookingStatusEnum("status").default("PENDING_PAYMENT").notNull(),
  price: integer("price").default(11000).notNull(),
  notes: text("notes"),
  createdBy: text("created_by").default("PUBLIC"),
  reminderSentAt: timestamp("reminder_sent_at"),
  reminderOneHourSentAt: timestamp("reminder_one_hour_sent_at"),
  reminderOneDaySentAt: timestamp("reminder_one_day_sent_at"),
  reminderThreeDaysSentAt: timestamp("reminder_three_days_sent_at"),
  deletedAt: timestamp("deleted_at"),
  cancellationReason: text("cancellation_reason"),
  meetLink: text("meet_link"),
  calendarEventId: text("calendar_event_id"),
  mercadoPagoPreferenceId: text("mercadopago_preference_id"),
  mercadoPagoPaymentId: text("mercadopago_payment_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Calendar Bookings (reservas REALES detectadas desde el feed iCal del calendario de Google).
// Sirven para reportar a Google Ads la conversion "Reunion agendada" solo cuando alguien agenda de verdad,
// en vez de contarla al entrar a /agendar. Dedupe por icalUid. Ver replit.md (Booking/Conversiones).
export const calendarBookings = pgTable("calendar_bookings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  icalUid: text("ical_uid").notNull().unique(),
  bookerName: text("booker_name"),
  bookerEmail: text("booker_email"),
  summary: text("summary"),
  meetingStart: timestamp("meeting_start"),
  meetingEnd: timestamp("meeting_end"),
  meetLink: text("meet_link"),
  status: text("status").default("CONFIRMED").notNull(),
  bookedAt: timestamp("booked_at"),
  exportedToAdsAt: timestamp("exported_to_ads_at"),
  detectedAt: timestamp("detected_at").defaultNow().notNull(),
});

export const insertCalendarBookingSchema = createInsertSchema(calendarBookings).omit({ id: true, detectedAt: true });
export type InsertCalendarBooking = z.infer<typeof insertCalendarBookingSchema>;
export type CalendarBooking = typeof calendarBookings.$inferSelect;

// Tabla genérica key-value para flags/marcadores durables del sistema.
// Uso actual: marcador one-shot de "baseline" de conversiones de reservas
// (clave calendar_bookings_baseline_done_at) para que el baseline se complete
// incluso si el primer sync ve el ICS vacío, independiente del número de filas.
export const appSettings = pgTable("app_settings", {
  key: text("key").primaryKey(),
  value: text("value"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertAppSettingSchema = createInsertSchema(appSettings).omit({ updatedAt: true });
export type InsertAppSetting = z.infer<typeof insertAppSettingSchema>;
export type AppSetting = typeof appSettings.$inferSelect;

// Expense Categories
export const expenseCategories = pgTable("expense_categories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  icon: text("icon"),
  color: text("color"),
  isDefault: integer("is_default").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Mercado Pago Transactions
export const mercadopagoTransactions = pgTable("mercadopago_transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  mpId: text("mp_id").notNull(),
  type: text("type").notNull(),
  amount: integer("amount").notNull(),
  description: text("description"),
  customDescription: text("custom_description"),
  categoryId: varchar("category_id"),
  categoryName: text("category_name"),
  date: timestamp("date").notNull(),
  status: text("status"),
  counterpartName: text("counterpart_name"),
  flowDirection: text("flow_direction").default("income"),
  rawData: jsonb("raw_data"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertExpenseCategorySchema = createInsertSchema(expenseCategories).omit({ id: true, createdAt: true });
export type InsertExpenseCategory = z.infer<typeof insertExpenseCategorySchema>;
export type ExpenseCategory = typeof expenseCategories.$inferSelect;

export const insertMercadopagoTransactionSchema = createInsertSchema(mercadopagoTransactions).omit({ id: true, createdAt: true });
export type InsertMercadopagoTransaction = z.infer<typeof insertMercadopagoTransactionSchema>;
export type MercadopagoTransaction = typeof mercadopagoTransactions.$inferSelect;

export const wasabilDocuments = pgTable("wasabil_documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  wasabilDocument: text("wasabil_document"),
  wasabilUuid: text("wasabil_uuid"),
  siiDocumentTypeCode: integer("sii_document_type_code").notNull(),
  siiDocumentTypeName: text("sii_document_type_name"),
  folio: integer("folio"),
  status: text("status").notNull().default("draft"),
  statusId: integer("status_id"),
  errorCode: text("error_code"),
  displayError: text("display_error"),
  receiverRut: text("receiver_rut"),
  receiverName: text("receiver_name"),
  receiverEmail: text("receiver_email"),
  receiverAddress: text("receiver_address"),
  receiverComuna: text("receiver_comuna"),
  receiverCity: text("receiver_city"),
  receiverGiro: text("receiver_giro"),
  currencySymbol: text("currency_symbol").default("CLP"),
  paymentMethod: text("payment_method"),
  subtotal: integer("subtotal"),
  iva: integer("iva"),
  total: integer("total"),
  details: jsonb("details"),
  references: jsonb("references"),
  sourceType: text("source_type"),
  sourceId: text("source_id"),
  invoiceReference: text("invoice_reference"),
  pdfUrl: text("pdf_url"),
  xmlUrl: text("xml_url"),
  documentDate: text("document_date"),
  rawResponse: jsonb("raw_response"),
  retryCount: integer("retry_count").default(0).notNull(),
  lastRetryAt: timestamp("last_retry_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertWasabilDocumentSchema = createInsertSchema(wasabilDocuments).omit({ id: true, createdAt: true });
export type InsertWasabilDocument = z.infer<typeof insertWasabilDocumentSchema>;
export type WasabilDocument = typeof wasabilDocuments.$inferSelect;

// Expenses for Financial Tracking
export const expenses = pgTable("expenses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  amount: integer("amount").notNull(),
  category: text("category").notNull(),
  description: text("description"),
  date: timestamp("date").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Manual Incomes (independent of projects)
export const incomes = pgTable("incomes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  amount: integer("amount").notNull(),
  category: text("category").notNull(),
  description: text("description"),
  clientName: text("client_name"),
  hasIVA: integer("has_iva").default(0).notNull(),
  date: timestamp("date").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Portfolio Projects (for public showcase)
export const portfolioItems = pgTable("portfolio_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  slug: text("slug").unique(),
  description: text("description"),
  imageUrl: text("image_url"),
  liveUrl: text("live_url"),
  category: text("category").notNull(),
  industry: text("industry"),
  stack: text("stack").array(),
  metrics: text("metrics").array(),
  status: text("status").default("production").notNull(),
  published: boolean("published").default(true).notNull(),
  featured: integer("featured").default(0).notNull(),
  sortOrder: integer("sort_order").default(0).notNull(),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  blogArticleId: varchar("blog_article_id").references(() => blogArticles.id),
  caseStudyUrl: text("case_study_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Client Logos (trusted by section)
export const clientLogos = pgTable("client_logos", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  logoUrl: text("logo_url"),
  websiteUrl: text("website_url"),
  sortOrder: integer("sort_order").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Testimonials
export const testimonials = pgTable("testimonials", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => projects.id),
  clientName: text("client_name").notNull(),
  position: text("position"),
  company: text("company"),
  industry: text("industry"),
  content: text("content").notNull(),
  rating: integer("rating").default(5).notNull(),
  avatarUrl: text("avatar_url"),
  companyLogoUrl: text("company_logo_url"),
  linkedinUrl: text("linkedin_url"),
  published: boolean("published").default(false).notNull(),
  displayOrder: integer("display_order").default(0).notNull(),
  featured: integer("featured").default(0).notNull(),
  publishedAt: timestamp("published_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const testimonialsRelations = relations(testimonials, ({ one }) => ({
  project: one(projects, {
    fields: [testimonials.projectId],
    references: [projects.id],
  }),
}));

export const insertTestimonialSchema = createInsertSchema(testimonials, {
  clientName: z.string().min(2, "Nombre obligatorio").max(100),
  position: z.string().min(2, "Cargo obligatorio").max(100),
  company: z.string().min(1, "Empresa obligatoria").max(100),
  content: z
    .string()
    .min(50, "El testimonio debe tener al menos 50 caracteres")
    .max(500, "Maximo 500 caracteres"),
  rating: z.number().int().min(1).max(5),
  avatarUrl: z
    .string()
    .refine((u) => !u || u.startsWith("/") || /^https?:\/\//.test(u), "Debe ser una URL o ruta valida")
    .optional()
    .nullable()
    .or(z.literal("")),
  companyLogoUrl: z
    .string()
    .refine((u) => !u || u.startsWith("/") || /^https?:\/\//.test(u), "Debe ser una URL o ruta valida")
    .optional()
    .nullable()
    .or(z.literal("")),
  linkedinUrl: z
    .string()
    .url("LinkedIn URL invalida")
    .refine((u) => !u || u.includes("linkedin.com"), "Debe ser un link de LinkedIn")
    .optional()
    .nullable()
    .or(z.literal("")),
  industry: z.string().max(100).optional().nullable().or(z.literal("")),
  displayOrder: z.number().int().default(0),
  published: z.boolean().default(false),
}).omit({ id: true, createdAt: true, updatedAt: true });

// Brand Videos (Videos de Marca) — carrusel vertical 9:16 en las landings de Ads.
export const brandVideos = pgTable("brand_videos", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  videoUrl: text("video_url").notNull(),
  posterUrl: text("poster_url"),
  title: text("title"),
  displayOrder: integer("display_order").default(0).notNull(),
  published: boolean("published").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertBrandVideoSchema = createInsertSchema(brandVideos, {
  videoUrl: z
    .string()
    .min(1, "El video es obligatorio")
    .refine((u) => u.startsWith("/") || /^https?:\/\//.test(u), "Debe ser una URL o ruta válida"),
  posterUrl: z
    .string()
    .refine((u) => !u || u.startsWith("/") || /^https?:\/\//.test(u), "Debe ser una URL o ruta válida")
    // La portada es una IMAGEN, nunca un enlace de video: un embed de
    // YouTube/TikTok/Instagram usado como <img> rompe la carátula.
    .refine(
      (u) => !u || !/(?:youtube\.com|youtu\.be|tiktok\.com|instagram\.com)/i.test(u),
      "La portada debe ser una imagen, no un enlace de video. Sube una imagen o pega la URL de una imagen.",
    )
    .optional()
    .nullable()
    .or(z.literal("")),
  title: z.string().max(120).optional().nullable().or(z.literal("")),
  displayOrder: z.number().int().default(0),
  published: z.boolean().default(true),
}).omit({ id: true, createdAt: true, updatedAt: true });

// Admin Notifications
export const notificationTypeEnum = pgEnum("notification_type", [
  "DESIGN_APPROVED",
  "DESIGN_CHANGES_REQUESTED",
  "NEW_TESTIMONIAL",
  "PROJECT_COMPLETED",
  "NEW_BOOKING",
  "PROPOSAL_APPROVED",
  "PROPOSAL_REJECTED",
  "CHANGE_REQUEST",
  "SERVICE_ACCEPTED",
  "AGREEMENT_SIGNED",
  "NEW_CHAT",
  "ADDON_APPROVED",
  "ADDON_REJECTED",
]);

export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: notificationTypeEnum("type").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  projectId: varchar("project_id").references(() => projects.id),
  clientId: varchar("client_id").references(() => clients.id),
  isRead: integer("is_read").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const notificationsRelations = relations(notifications, ({ one }) => ({
  project: one(projects, {
    fields: [notifications.projectId],
    references: [projects.id],
  }),
  client: one(clients, {
    fields: [notifications.clientId],
    references: [clients.id],
  }),
}));

// Coupons for referral/loyalty program and promotional campaigns
export const coupons = pgTable("coupons", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  code: text("code").notNull().unique(),
  name: text("name"), // Custom name for promotional coupons (e.g., "Promo Año Nuevo 2026")
  discountPercent: integer("discount_percent").notNull().default(10),
  discountAmount: integer("discount_amount"), // Fixed amount discount (alternative to percentage)
  eventType: text("event_type"), // Event category: NEW_YEAR, VALENTINES, MOTHERS_DAY, FATHERS_DAY, FIESTAS_PATRIAS, HALLOWEEN, BLACK_FRIDAY, CYBER_MONDAY, CHRISTMAS, CUSTOM
  isPromotion: integer("is_promotion").default(0).notNull(), // 1 = promotional coupon, 0 = loyalty/referral coupon
  maxUses: integer("max_uses"), // null = unlimited, number = max uses allowed
  usageCount: integer("usage_count").default(0).notNull(), // Current number of times used
  issuedToClientId: varchar("issued_to_client_id").references(() => clients.id),
  issuedFromProjectId: varchar("issued_from_project_id").references(() => projects.id),
  usedByClientId: varchar("used_by_client_id").references(() => clients.id),
  usedOnProposalId: varchar("used_on_proposal_id").references(() => proposals.id),
  usedOnProjectId: varchar("used_on_project_id").references(() => projects.id),
  includesFreeMeeting: integer("includes_free_meeting").default(1).notNull(),
  isUsed: integer("is_used").default(0).notNull(),
  originalDocumentUrl: text("original_document_url"), // PDF/contract document for traceability
  validFrom: timestamp("valid_from"), // Start date of validity
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const couponsRelations = relations(coupons, ({ one }) => ({
  issuedToClient: one(clients, {
    fields: [coupons.issuedToClientId],
    references: [clients.id],
  }),
  issuedFromProject: one(projects, {
    fields: [coupons.issuedFromProjectId],
    references: [projects.id],
  }),
}));

// Service type enum for maintenance contracts (includes LLAVE for POS licenses)
export const serviceTypeEnum = pgEnum("service_type", ["HOSTING", "SUPPORT", "BUNDLE", "LLAVE", "HOSTING_MANTENIMIENTO"]);

// Payment status enum for maintenance payments
export const maintenancePaymentStatusEnum = pgEnum("maintenance_payment_status", ["PENDING", "PAID", "LATE", "WAIVED"]);

// Project completion offers (hosting + maintenance bundle)
export const completionOffers = pgTable("completion_offers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => projects.id).notNull(),
  clientId: varchar("client_id").references(() => clients.id).notNull(),
  hostingPrice: integer("hosting_price").default(20000).notNull(),
  supportPrice: integer("support_price").default(20000).notNull(),
  bundlePrice: integer("bundle_price").default(25000).notNull(),
  acceptedBundle: integer("accepted_bundle").default(0).notNull(),
  selectedService: text("selected_service"),
  couponId: varchar("coupon_id").references(() => coupons.id),
  respondedAt: timestamp("responded_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Maintenance contracts for active hosting/support/license services
export const maintenanceContracts = pgTable("maintenance_contracts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => projects.id),
  clientId: varchar("client_id").references(() => clients.id).notNull(),
  serviceType: text("service_type").notNull(), // HOSTING, SUPPORT, BUNDLE, LLAVE, or HOSTING_MANTENIMIENTO
  monthlyPrice: integer("monthly_price").notNull(),
  hasIVA: integer("has_iva").default(0).notNull(), // 1 = include IVA (19%), 0 = no IVA
  status: text("status").default("ACTIVE").notNull(),
  licenseKey: text("license_key"), // For LLAVE type: the POS license key assigned
  startDate: timestamp("start_date").defaultNow().notNull(),
  endDate: timestamp("end_date"),
  notes: text("notes"),
  notifyPhones: text("notify_phones").array(),
  notifyEmails: text("notify_emails").array(),
  lastPaymentReminderSent: timestamp("last_payment_reminder_sent"),
  lastWhatsappReminderSent: timestamp("last_whatsapp_reminder_sent"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const maintenanceContractsRelations = relations(maintenanceContracts, ({ one, many }) => ({
  project: one(projects, {
    fields: [maintenanceContracts.projectId],
    references: [projects.id],
  }),
  client: one(clients, {
    fields: [maintenanceContracts.clientId],
    references: [clients.id],
  }),
  payments: many(maintenancePayments),
}));

// Maintenance payments for tracking monthly payments (Jan-Dec calendar)
export const maintenancePayments = pgTable("maintenance_payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  contractId: varchar("contract_id").references(() => maintenanceContracts.id).notNull(),
  month: integer("month").notNull(), // 1-12
  year: integer("year").notNull(),
  amount: integer("amount").notNull(),
  status: maintenancePaymentStatusEnum("status").default("PENDING").notNull(),
  dueDate: timestamp("due_date").notNull(),
  paidAt: timestamp("paid_at"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const maintenancePaymentsRelations = relations(maintenancePayments, ({ one }) => ({
  contract: one(maintenanceContracts, {
    fields: [maintenancePayments.contractId],
    references: [maintenanceContracts.id],
  }),
}));

export const completionOffersRelations = relations(completionOffers, ({ one }) => ({
  project: one(projects, {
    fields: [completionOffers.projectId],
    references: [projects.id],
  }),
  client: one(clients, {
    fields: [completionOffers.clientId],
    references: [clients.id],
  }),
  coupon: one(coupons, {
    fields: [completionOffers.couponId],
    references: [coupons.id],
  }),
}));

// Payment method enum
export const paymentMethodEnum = pgEnum("payment_method", ["TRANSFERENCIA", "EFECTIVO", "TARJETA", "OTRO"]);

// Payments tracking per project
export const payments = pgTable("payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => projects.id).notNull(),
  amount: integer("amount").notNull(),
  paymentMethod: paymentMethodEnum("payment_method").default("TRANSFERENCIA").notNull(),
  description: text("description"),
  hasIVA: integer("has_iva").default(0).notNull(),
  paymentDate: timestamp("payment_date").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const paymentsRelations = relations(payments, ({ one }) => ({
  project: one(projects, {
    fields: [payments.projectId],
    references: [projects.id],
  }),
}));

// Change request status enum
export const changeRequestStatusEnum = pgEnum("change_request_status", ["PENDING", "IN_PROGRESS", "COMPLETED", "REJECTED"]);

// Client change requests
export const changeRequests = pgTable("change_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => projects.id).notNull(),
  clientId: varchar("client_id").references(() => clients.id).notNull(),
  message: text("message").notNull(),
  status: changeRequestStatusEnum("status").default("PENDING").notNull(),
  adminResponse: text("admin_response"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  resolvedAt: timestamp("resolved_at"),
});

export const changeRequestsRelations = relations(changeRequests, ({ one }) => ({
  project: one(projects, {
    fields: [changeRequests.projectId],
    references: [projects.id],
  }),
  client: one(clients, {
    fields: [changeRequests.clientId],
    references: [clients.id],
  }),
}));

// Contact form leads (for tracking all contact submissions)
export const contactStatusEnum = pgEnum("contact_status", [
  "NEW",           // Nuevo - recién llegado
  "PENDING",       // Pendiente - por responder
  "CONTACTED",     // Contactado - ya se respondió
  "CONVERTED",     // Convertido - se convirtió en cliente
  "NOT_RELEVANT",  // No relevante - spam o no aplica
  "CLOSED"         // Cerrado - caso cerrado sin conversión
]);

export const contacts = pgTable("contacts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  company: text("company"),
  message: text("message").notNull(),
  serviceInterest: text("service_interest"),
  requestType: text("request_type"),
  status: contactStatusEnum("status").default("NEW").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertContactSchema = createInsertSchema(contacts).omit({ id: true, createdAt: true });
export type InsertContact = z.infer<typeof insertContactSchema>;
export type Contact = typeof contacts.$inferSelect;

// Insert schemas
export const insertClientSchema = createInsertSchema(clients).omit({ id: true, createdAt: true });
export const insertServiceSchema = createInsertSchema(services).omit({ id: true });
export const insertProposalSchema = createInsertSchema(proposals).omit({ id: true, createdAt: true, updatedAt: true });
export const insertProposalItemSchema = createInsertSchema(proposalItems).omit({ id: true });
export const insertProjectSchema = createInsertSchema(projects).omit({ id: true, createdAt: true });
export const insertTaskSchema = createInsertSchema(tasks).omit({ id: true, createdAt: true });
export const insertProjectLogSchema = createInsertSchema(projectLogs).omit({ id: true, createdAt: true });
export const insertAvailabilitySlotSchema = createInsertSchema(availabilitySlots).omit({ id: true, createdAt: true });
export const insertBlockedWeekSchema = createInsertSchema(blockedWeeks).omit({ id: true, createdAt: true });
export const insertBookingSchema = createInsertSchema(bookings).omit({ id: true, createdAt: true });
export const insertExpenseSchema = createInsertSchema(expenses).omit({ id: true, createdAt: true });
export const insertIncomeSchema = createInsertSchema(incomes).omit({ id: true, createdAt: true });
export const insertPortfolioItemSchema = createInsertSchema(portfolioItems).omit({ id: true, createdAt: true }).extend({
  slug: z.string().min(1, "Slug requerido").regex(/^[a-z0-9-]+$/, "Slug debe ser kebab-case (a-z, 0-9, -)"),
  status: z.enum(["production", "in-development", "archived"]).default("production"),
});
export const insertClientLogoSchema = createInsertSchema(clientLogos).omit({ id: true, createdAt: true });
export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true, createdAt: true });
export const insertCouponSchema = createInsertSchema(coupons).omit({ id: true, createdAt: true });
export const insertCompletionOfferSchema = createInsertSchema(completionOffers).omit({ id: true, createdAt: true });
export const insertPaymentSchema = createInsertSchema(payments).omit({ id: true, createdAt: true });
export const insertMaintenanceContractSchema = createInsertSchema(maintenanceContracts).omit({ id: true, createdAt: true });
export const insertMaintenancePaymentSchema = createInsertSchema(maintenancePayments).omit({ id: true, createdAt: true, updatedAt: true });
export const insertChangeRequestSchema = createInsertSchema(changeRequests).omit({ id: true, createdAt: true, resolvedAt: true });

// Types
export type InsertClient = z.infer<typeof insertClientSchema>;
export type Client = typeof clients.$inferSelect;
export type InsertService = z.infer<typeof insertServiceSchema>;
export type Service = typeof services.$inferSelect;
export type InsertProposal = z.infer<typeof insertProposalSchema>;
export type Proposal = typeof proposals.$inferSelect;
export type InsertProposalItem = z.infer<typeof insertProposalItemSchema>;
export type ProposalItem = typeof proposalItems.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;
export type InsertProjectLog = z.infer<typeof insertProjectLogSchema>;
export type ProjectLog = typeof projectLogs.$inferSelect;
export type InsertAvailabilitySlot = z.infer<typeof insertAvailabilitySlotSchema>;
export type AvailabilitySlot = typeof availabilitySlots.$inferSelect;
export type InsertBlockedWeek = z.infer<typeof insertBlockedWeekSchema>;
export type BlockedWeek = typeof blockedWeeks.$inferSelect;
export type InsertBooking = z.infer<typeof insertBookingSchema>;
export type Booking = typeof bookings.$inferSelect;
export type InsertExpense = z.infer<typeof insertExpenseSchema>;
export type Expense = typeof expenses.$inferSelect;
export type InsertIncome = z.infer<typeof insertIncomeSchema>;
export type Income = typeof incomes.$inferSelect;
export type InsertPortfolioItem = z.infer<typeof insertPortfolioItemSchema>;
export type PortfolioItem = typeof portfolioItems.$inferSelect;
export type InsertClientLogo = z.infer<typeof insertClientLogoSchema>;
export type ClientLogo = typeof clientLogos.$inferSelect;
export type InsertTestimonial = z.infer<typeof insertTestimonialSchema>;
export type Testimonial = typeof testimonials.$inferSelect;

export type InsertBrandVideo = z.infer<typeof insertBrandVideoSchema>;
export type BrandVideo = typeof brandVideos.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertCoupon = z.infer<typeof insertCouponSchema>;
export type Coupon = typeof coupons.$inferSelect;
export type InsertCompletionOffer = z.infer<typeof insertCompletionOfferSchema>;
export type CompletionOffer = typeof completionOffers.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof payments.$inferSelect;
export type InsertMaintenanceContract = z.infer<typeof insertMaintenanceContractSchema>;
export type MaintenanceContract = typeof maintenanceContracts.$inferSelect;
export type InsertMaintenancePayment = z.infer<typeof insertMaintenancePaymentSchema>;
export type MaintenancePayment = typeof maintenancePayments.$inferSelect;
export type InsertChangeRequest = z.infer<typeof insertChangeRequestSchema>;
export type ChangeRequest = typeof changeRequests.$inferSelect;

// Client Portal Users (for mobile app access)
export const clientPortalUsers = pgTable("client_portal_users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").unique().notNull(),
  passwordHash: text("password_hash").notNull(),
  tempPassword: text("temp_password"),
  name: text("name"),
  phone: text("phone"),
  company: text("company"),
  clientId: varchar("client_id").references(() => clients.id),
  role: text("role").default("client").notNull(),
  isActive: integer("is_active").default(1).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertClientPortalUserSchema = createInsertSchema(clientPortalUsers).omit({ id: true, createdAt: true });
export type InsertClientPortalUser = z.infer<typeof insertClientPortalUserSchema>;
export type ClientPortalUser = typeof clientPortalUsers.$inferSelect;

// TikTok OAuth Tokens
export const tiktokTokens = pgTable("tiktok_tokens", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  accessToken: text("access_token").notNull(),
  advertiserId: text("advertiser_id").notNull(),
  advertiserName: text("advertiser_name"),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertTiktokTokenSchema = createInsertSchema(tiktokTokens).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertTiktokToken = z.infer<typeof insertTiktokTokenSchema>;
export type TiktokToken = typeof tiktokTokens.$inferSelect;

// Extended types for frontend
export type ProposalWithItems = Proposal & {
  items: ProposalItem[];
  client: Client;
};

export type ProjectWithDetails = Project & {
  client: Client;
  tasks: Task[];
};

// Analytics Events - for tracking user interactions
export const analyticsEventTypeEnum = pgEnum("analytics_event_type", ["FORM_SUBMIT", "WHATSAPP_CLICK", "LINK_CLICK", "PAGE_VIEW", "BUTTON_CLICK"]);

export const analyticsEvents = pgTable("analytics_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  eventType: analyticsEventTypeEnum("event_type").notNull(),
  eventName: text("event_name").notNull(), // e.g., "contact_form", "booking_whatsapp", "portfolio_view"
  eventData: text("event_data"), // JSON string for additional data
  pageUrl: text("page_url"),
  referrer: text("referrer"),
  userAgent: text("user_agent"),
  ipAddress: text("ip_address"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAnalyticsEventSchema = createInsertSchema(analyticsEvents).omit({ id: true, createdAt: true });
export type InsertAnalyticsEvent = z.infer<typeof insertAnalyticsEventSchema>;
export type AnalyticsEvent = typeof analyticsEvents.$inferSelect;

// Service Agreement Enums
export const agreementStatusEnum = pgEnum("agreement_status", ["DRAFT", "PENDING_SIGNATURE", "SIGNED", "EXPIRED"]);
export const agreementTemplateTypeEnum = pgEnum("agreement_template_type", ["LANDING_PAGE", "WEBSITE", "ECOMMERCE", "WEB_APP", "MOBILE_APP", "CUSTOM"]);
export const signatureTypeEnum = pgEnum("signature_type", ["DRAWN", "UPLOAD", "TYPED"]);

// Agreement Templates - Plantillas predefinidas para diferentes tipos de servicios
export const agreementTemplates = pgTable("agreement_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  templateType: agreementTemplateTypeEnum("template_type").notNull(),
  content: text("content").notNull(), // Contenido completo del acuerdo en formato estructurado
  isDefault: integer("is_default").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Service Agreements - Acuerdos de servicio individuales por propuesta
export const serviceAgreements = pgTable("service_agreements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  proposalId: varchar("proposal_id").references(() => proposals.id).notNull(),
  templateId: varchar("template_id").references(() => agreementTemplates.id),
  tokenUrl: text("token_url").unique().notNull(),
  status: agreementStatusEnum("status").default("DRAFT").notNull(),
  
  // Datos del contratante (cliente)
  clientCompanyName: text("client_company_name").notNull(),
  clientRut: text("client_rut"),
  clientRepresentativeName: text("client_representative_name").notNull(),
  clientRepresentativeRut: text("client_representative_rut"),
  
  // Contenido del acuerdo (puede ser personalizado desde plantilla)
  content: text("content").notNull(),
  
  // Datos de firma electrónica
  signedAt: timestamp("signed_at"),
  signedByName: text("signed_by_name"),
  signedByEmail: text("signed_by_email"),
  signedByIp: text("signed_by_ip"),
  signatureType: signatureTypeEnum("signature_type"), // DRAWN, UPLOAD, TYPED
  signatureData: text("signature_data"), // Canvas de firma en base64 o texto de firma tipográfica
  signatureImageUrl: text("signature_image_url"), // URL de imagen de firma subida
  signedPdfUrl: text("signed_pdf_url"), // URL del PDF firmado generado
  
  // Metadatos
  validUntil: timestamp("valid_until"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const serviceAgreementsRelations = relations(serviceAgreements, ({ one }) => ({
  proposal: one(proposals, {
    fields: [serviceAgreements.proposalId],
    references: [proposals.id],
  }),
  template: one(agreementTemplates, {
    fields: [serviceAgreements.templateId],
    references: [agreementTemplates.id],
  }),
}));

export const insertAgreementTemplateSchema = createInsertSchema(agreementTemplates).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertAgreementTemplate = z.infer<typeof insertAgreementTemplateSchema>;
export type AgreementTemplate = typeof agreementTemplates.$inferSelect;

export const insertServiceAgreementSchema = createInsertSchema(serviceAgreements).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertServiceAgreement = z.infer<typeof insertServiceAgreementSchema>;
export type ServiceAgreement = typeof serviceAgreements.$inferSelect;

// Extended type for agreement with proposal details
export type ServiceAgreementWithDetails = ServiceAgreement & {
  proposal: Proposal & { client: Client; items: ProposalItem[] };
};

// Blog Categories - Dynamic categories with custom colors and icons
export const blogCategories = pgTable("blog_categories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  slug: text("slug").unique().notNull(),
  color: text("color").notNull().default("#4A7C34"),
  icon: text("icon").notNull().default("Folder"),
  isActive: integer("is_active").default(1).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertBlogCategorySchema = createInsertSchema(blogCategories).omit({ id: true, createdAt: true });
export type InsertBlogCategory = z.infer<typeof insertBlogCategorySchema>;
export type BlogCategory = typeof blogCategories.$inferSelect;

// Blog Articles - Auto-generated educational content
export const blogCategoryEnum = pgEnum("blog_category", ["DESARROLLO_WEB", "INTELIGENCIA_ARTIFICIAL", "CIBERSEGURIDAD", "INFORMATICA_GENERAL", "TENDENCIAS"]);

export const blogArticles = pgTable("blog_articles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  slug: text("slug").unique().notNull(),
  title: text("title").notNull(),
  excerpt: text("excerpt").notNull(),
  content: text("content").notNull(),
  category: blogCategoryEnum("category").default("INFORMATICA_GENERAL").notNull(),
  categoryId: varchar("category_id").references(() => blogCategories.id),
  sourceUrl: text("source_url"),
  sourceTitle: text("source_title"),
  imageUrl: text("image_url"),
  isPublished: integer("is_published").default(1).notNull(),
  viewCount: integer("view_count").default(0).notNull(),
  publishedAt: timestamp("published_at").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertBlogArticleSchema = createInsertSchema(blogArticles).omit({ id: true, createdAt: true, viewCount: true });
export type InsertBlogArticle = z.infer<typeof insertBlogArticleSchema>;
export type BlogArticle = typeof blogArticles.$inferSelect;

// Blog Subscribers - Email subscriptions for new article notifications
export const blogSubscribers = pgTable("blog_subscribers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").unique().notNull(),
  isActive: integer("is_active").default(1).notNull(),
  unsubscribeToken: text("unsubscribe_token").unique().notNull(),
  subscribedAt: timestamp("subscribed_at").defaultNow().notNull(),
});

export const insertBlogSubscriberSchema = createInsertSchema(blogSubscribers).omit({ id: true, subscribedAt: true, unsubscribeToken: true });
export type InsertBlogSubscriber = z.infer<typeof insertBlogSubscriberSchema>;
export type BlogSubscriber = typeof blogSubscribers.$inferSelect;

// Innovation Hub - Ideas Management
export const ideaStatusEnum = pgEnum("idea_status", ["banco", "planificacion", "realizado"]);

// Categorías persistentes para ideas
export const ideaCategories = pgTable("idea_categories", {
  id: serial("id").primaryKey(),
  nombre: text("nombre").notNull().unique(),
  color: text("color").default("#9333ea"), // Color para identificar visualmente
  descripcion: text("descripcion"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertIdeaCategorySchema = createInsertSchema(ideaCategories).omit({ id: true, createdAt: true });
export type InsertIdeaCategory = z.infer<typeof insertIdeaCategorySchema>;
export type IdeaCategory = typeof ideaCategories.$inferSelect;

export const ideas = pgTable("ideas", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  titulo: text("titulo").notNull(),
  contenidoDetallado: text("contenido_detallado"),
  categoria: text("categoria"), // Texto legacy - mantener para compatibilidad
  categoriaId: integer("categoria_id").references(() => ideaCategories.id), // Nueva relación
  prioridad: integer("prioridad").default(2).notNull(), // 1=baja, 2=media, 3=alta
  estado: ideaStatusEnum("estado").default("banco").notNull(),
  tags: text("tags").array(),
  recursos: text("recursos"), // JSON string: [{titulo: string, url: string}]
  bitacora: text("bitacora"), // JSON string: [{fecha: string, nota: string}]
  fechaInicio: timestamp("fecha_inicio"), // Nueva: fecha de inicio del trabajo
  fechaObjetivo: timestamp("fecha_objetivo"), // Fecha de fin/objetivo
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertIdeaSchema = createInsertSchema(ideas).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertIdea = z.infer<typeof insertIdeaSchema>;
export type Idea = typeof ideas.$inferSelect;

// TikTok Ads Automation - Configuration
export const tiktokAdsConfig = pgTable("tiktok_ads_config", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  campaignId: text("campaign_id"),
  campaignName: text("campaign_name").default("WebMaker - Auto Ads"),
  adgroupId: text("adgroup_id"),
  adgroupName: text("adgroup_name").default("Auto Videos Diarios"),
  objectiveType: text("objective_type").default("LEAD_GENERATION"),
  promotionType: text("promotion_type").default("WEBSITE"),
  optimizationGoal: text("optimization_goal").default("CONVERT"),
  landingPageUrl: text("landing_page_url").default("https://webmakerlatam.com"),
  adTextTemplate: text("ad_text_template").default("WebMaker - Desarrollo Web Profesional"),
  callToAction: text("call_to_action").default("LEARN_MORE"),
  pixelId: text("pixel_id").default("D5E7E1JC77U7EM1QCFN0"),
  billingEvent: text("billing_event").default("CPC"),
  dailyBudgetClp: integer("daily_budget_clp").default(57000).notNull(),
  weeklyBudgetCapClp: integer("weekly_budget_cap_clp").default(400000).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  locationIds: text("location_ids").array(),
  campaignStartDate: timestamp("campaign_start_date"),
  campaignEndDate: timestamp("campaign_end_date"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertTiktokAdsConfigSchema = createInsertSchema(tiktokAdsConfig).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertTiktokAdsConfig = z.infer<typeof insertTiktokAdsConfigSchema>;
export type TiktokAdsConfig = typeof tiktokAdsConfig.$inferSelect;

// TikTok Ads Automation - Video Status Enum
export const tiktokAdVideoStatusEnum = pgEnum("tiktok_ad_video_status", [
  "QUEUED", "UPLOADING", "UPLOADED", "AD_CREATED", "ACTIVE", "FAILED", "CANCELLED"
]);

// TikTok Ads Automation - Ad Videos
export const tiktokAdVideos = pgTable("tiktok_ad_videos", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fileName: text("file_name").notNull(),
  fileUrl: text("file_url").notNull(),
  videoName: text("video_name"),
  adText: text("ad_text"),
  scheduledDate: timestamp("scheduled_date").notNull(),
  status: tiktokAdVideoStatusEnum("status").default("QUEUED").notNull(),
  tiktokVideoId: text("tiktok_video_id"),
  tiktokAdId: text("tiktok_ad_id"),
  errorMessage: text("error_message"),
  processedAt: timestamp("processed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTiktokAdVideoSchema = createInsertSchema(tiktokAdVideos).omit({ id: true, createdAt: true });
export type InsertTiktokAdVideo = z.infer<typeof insertTiktokAdVideoSchema>;
export type TiktokAdVideo = typeof tiktokAdVideos.$inferSelect;

// Live Chat System
export const chatConversationStatusEnum = pgEnum("chat_conversation_status", [
  "ACTIVE", "CLOSED", "ADMIN_JOINED"
]);

export const chatBudgetRangeEnum = pgEnum("chat_budget_range", [
  "menos_500k", "500k_1.5m", "1.5m_5m", "mas_5m", "sin_definir"
]);

export const chatTimingEnum = pgEnum("chat_timing", [
  "esta_semana", "este_mes", "3_meses", "explorando"
]);

export const chatLeadScoreEnum = pgEnum("chat_lead_score", [
  "HOT", "WARM", "COLD", "UNQUALIFIED"
]);

export const chatConversations = pgTable("chat_conversations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: text("session_id").notNull().unique(),
  contactName: text("contact_name").notNull(),
  contactEmail: text("contact_email").notNull(),
  contactPhone: text("contact_phone"),
  problemType: text("problem_type"),
  specificDetail: text("specific_detail"),
  channel: text("channel").default("web").notNull(),
  status: chatConversationStatusEnum("status").default("ACTIVE").notNull(),
  botPaused: boolean("bot_paused").default(false).notNull(),
  ratingRequested: boolean("rating_requested").default(false).notNull(),
  rating: integer("rating"),
  ratingComment: text("rating_comment"),
  ratedAt: timestamp("rated_at"),
  adminLastReadAt: timestamp("admin_last_read_at"),
  blocked: boolean("blocked").default(false).notNull(),
  warningCount: integer("warning_count").default(0).notNull(),
  isMuted: boolean("is_muted").default(false).notNull(),
  isArchived: boolean("is_archived").default(false).notNull(),
  assignedCloserId: varchar("assigned_closer_id"),
  assignedCloserName: text("assigned_closer_name"),
  assignedAt: timestamp("assigned_at"),
  lastAgentActivityAt: timestamp("last_agent_activity_at"),
  lastClientMessageAt: timestamp("last_client_message_at"),
  timeoutWarnedAt: timestamp("timeout_warned_at"),
  pendingTransferToId: varchar("pending_transfer_to_id"),
  pendingTransferToName: text("pending_transfer_to_name"),
  pendingTransferFromName: text("pending_transfer_from_name"),
  pendingTransferNote: text("pending_transfer_note"),
  pendingTransferAt: timestamp("pending_transfer_at"),
  budgetRange: chatBudgetRangeEnum("budget_range"),
  timing: chatTimingEnum("timing"),
  country: text("country"),
  leadScore: chatLeadScoreEnum("lead_score").default("UNQUALIFIED"),
  hotNotifiedAt: timestamp("hot_notified_at"),
  coldNotifiedAt: timestamp("cold_notified_at"),
  source: text("source"),
  // Urgencia "AHORA": el cliente quiere reunión o llamada en este momento.
  // Va en columna propia y no como valor del enum de score a propósito: un
  // lead urgente TAMBIÉN es HOT, y meterlo en el enum haría que
  // `leadScore === "HOT"` diera falso justo en el caso más caliente, apagando
  // las notificaciones y sacándolo de los filtros del panel.
  urgentAt: timestamp("urgent_at"),
  urgentNotifiedAt: timestamp("urgent_notified_at"),
  /** Ya se le ofreció el cupo más cercano tras los 5 min sin respuesta de Lucas. */
  urgentFallbackAt: timestamp("urgent_fallback_at"),
  // Reunión agendada por el agente en Calendly.
  meetingEventUri: text("meeting_event_uri"),
  meetingLink: text("meeting_link"),
  meetingAt: timestamp("meeting_at"),
  // Anuncio de origen (click-to-WhatsApp de Meta). Llega en el webhook de
  // Twilio y hasta ahora se perdía: sin esto no se sabe qué anuncio trae cada
  // lead ni se puede medir el retorno por campaña.
  referralHeadline: text("referral_headline"),
  referralBody: text("referral_body"),
  referralSourceId: text("referral_source_id"),
  referralCtwaClid: text("referral_ctwa_clid"),
  lastMessageAt: timestamp("last_message_at").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertChatConversationSchema = createInsertSchema(chatConversations).omit({ id: true, createdAt: true });
export type InsertChatConversation = z.infer<typeof insertChatConversationSchema>;
export type ChatConversation = typeof chatConversations.$inferSelect;

export const chatMessageRoleEnum = pgEnum("chat_message_role", [
  "user", "assistant", "admin"
]);

export const chatMessages = pgTable("chat_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  conversationId: varchar("conversation_id").notNull().references(() => chatConversations.id),
  role: chatMessageRoleEnum("role").notNull(),
  content: text("content").notNull(),
  isSystem: boolean("is_system").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({ id: true, createdAt: true });
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;

// Auditoría de asignaciones de chat (tomar / liberar / transferir / timeout / override_admin)
export const chatAssignmentHistory = pgTable("chat_assignment_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  chatId: varchar("chat_id").notNull().references(() => chatConversations.id),
  fromUserId: varchar("from_user_id"),
  fromUserName: text("from_user_name"),
  toUserId: varchar("to_user_id"),
  toUserName: text("to_user_name"),
  action: text("action").notNull(),
  note: text("note"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertChatAssignmentHistorySchema = createInsertSchema(chatAssignmentHistory).omit({ id: true, createdAt: true });
export type InsertChatAssignmentHistory = z.infer<typeof insertChatAssignmentHistorySchema>;
export type ChatAssignmentHistory = typeof chatAssignmentHistory.$inferSelect;

// Push Subscriptions
export const pushSubscriptions = pgTable("push_subscriptions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id"),
  endpoint: text("endpoint").notNull().unique(),
  p256dh: text("p256dh").notNull(),
  auth: text("auth").notNull(),
  replyToken: text("reply_token").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertPushSubscriptionSchema = createInsertSchema(pushSubscriptions).omit({ id: true, createdAt: true, replyToken: true });
export type InsertPushSubscription = z.infer<typeof insertPushSubscriptionSchema> & { replyToken?: string };
export type PushSubscription = typeof pushSubscriptions.$inferSelect;

export const teamPushSubscriptions = pgTable("team_push_subscriptions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  userRole: varchar("user_role").notNull(),
  endpoint: text("endpoint").notNull().unique(),
  p256dh: text("p256dh").notNull(),
  auth: text("auth").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Chat Configuration
export const chatConfig = pgTable("chat_config", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  aiEnabled: boolean("ai_enabled").default(true).notNull(),
  businessHoursEnabled: boolean("business_hours_enabled").default(false).notNull(),
  businessHoursStart: text("business_hours_start").default("09:00"),
  businessHoursEnd: text("business_hours_end").default("18:00"),
  businessHoursTimezone: text("business_hours_timezone").default("America/Santiago"),
  ticketUrl: text("ticket_url"),
  welcomeMessage: text("welcome_message").default("Hola, soy el asistente virtual de WebMaker. En que puedo ayudarte?"),
  offlineMessage: text("offline_message").default("Estamos fuera de horario. Puedes dejar un ticket y te responderemos pronto."),
  emailNotificationsEnabled: boolean("email_notifications_enabled").default(true).notNull(),
  notificationEmail: text("notification_email"),
  inactivityTimeoutMinutes: integer("inactivity_timeout_minutes").default(15).notNull(),
  timeoutAction: text("timeout_action").default("queue").notNull(),
  transferRequiresAcceptance: boolean("transfer_requires_acceptance").default(false).notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertChatConfigSchema = createInsertSchema(chatConfig).omit({ id: true, updatedAt: true });
export type InsertChatConfig = z.infer<typeof insertChatConfigSchema>;
export type ChatConfig = typeof chatConfig.$inferSelect;

// Canned Responses (Quick replies for agents)
export const cannedResponses = pgTable("canned_responses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  shortcut: text("shortcut").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  category: text("category"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCannedResponseSchema = createInsertSchema(cannedResponses).omit({ id: true, createdAt: true });
export type InsertCannedResponse = z.infer<typeof insertCannedResponseSchema>;
export type CannedResponse = typeof cannedResponses.$inferSelect;

// Chat Tags
export const chatTags = pgTable("chat_tags", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull().unique(),
  color: text("color").default("#E86A30").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertChatTagSchema = createInsertSchema(chatTags).omit({ id: true, createdAt: true });
export type InsertChatTag = z.infer<typeof insertChatTagSchema>;
export type ChatTag = typeof chatTags.$inferSelect;

// Chat Conversation Tags (many-to-many)
export const chatConversationTags = pgTable("chat_conversation_tags", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  conversationId: varchar("conversation_id").notNull().references(() => chatConversations.id),
  tagId: varchar("tag_id").notNull().references(() => chatTags.id),
});

export type ChatConversationTag = typeof chatConversationTags.$inferSelect;

// AI Knowledge Base
export const knowledgeStatusEnum = pgEnum("knowledge_status", [
  "PENDING", "APPROVED", "REJECTED"
]);

export const chatKnowledgeBase = pgTable("chat_knowledge_base", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  category: text("category").notNull(),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  source: text("source"),
  conversationId: varchar("conversation_id"),
  status: knowledgeStatusEnum("status").default("PENDING").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertChatKnowledgeSchema = createInsertSchema(chatKnowledgeBase).omit({ id: true, createdAt: true });
export type InsertChatKnowledge = z.infer<typeof insertChatKnowledgeSchema>;
export type ChatKnowledge = typeof chatKnowledgeBase.$inferSelect;

// Chatbot Users (independent auth for /chatbot section)
export const chatbotUsers = pgTable("chatbot_users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  name: text("name").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  rememberToken: text("remember_token"),
  profileColor: text("profile_color"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertChatbotUserSchema = createInsertSchema(chatbotUsers).omit({ id: true, createdAt: true });
export type InsertChatbotUser = z.infer<typeof insertChatbotUserSchema>;
export type ChatbotUser = typeof chatbotUsers.$inferSelect;

export const adminUsers = pgTable("admin_users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  name: text("name").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAdminUserSchema = createInsertSchema(adminUsers).omit({ id: true, createdAt: true });
export type InsertAdminUser = z.infer<typeof insertAdminUserSchema>;
export type AdminUser = typeof adminUsers.$inferSelect;

export const teamMessages = pgTable("team_messages", {
  id: serial("id").primaryKey(),
  projectId: varchar("project_id").references(() => projects.id),
  proposalId: varchar("proposal_id"),
  senderId: varchar("sender_id").notNull(),
  senderRole: text("sender_role").notNull(),
  senderName: text("sender_name").notNull(),
  recipientId: varchar("recipient_id").notNull(),
  recipientRole: text("recipient_role").notNull(),
  content: text("content").notNull(),
  attachmentUrl: text("attachment_url"),
  attachmentType: text("attachment_type"),
  attachmentName: text("attachment_name"),
  isRead: boolean("is_read").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTeamMessageSchema = createInsertSchema(teamMessages).omit({ id: true, createdAt: true, isRead: true });
export type InsertTeamMessage = z.infer<typeof insertTeamMessageSchema>;
export type TeamMessage = typeof teamMessages.$inferSelect;

export const aiVideoIdeas = pgTable("ai_video_ideas", {
  id: serial("id").primaryKey(),
  titulo: text("titulo").notNull(),
  descripcion: text("descripcion").notNull(),
  guion: text("guion").notNull(),
  plataforma: text("plataforma").notNull(),
  tendencia: text("tendencia"),
  duracionSugerida: text("duracion_sugerida"),
  hashtags: text("hashtags").array(),
  saved: boolean("saved").default(false).notNull(),
  batchDate: text("batch_date").notNull(),
  recordedAt: timestamp("recorded_at"),
  category: text("category").default("corto-viral").notNull(),
  coverImageUrl: text("cover_image_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAiVideoIdeaSchema = createInsertSchema(aiVideoIdeas).omit({ id: true, createdAt: true });
export type InsertAiVideoIdea = z.infer<typeof insertAiVideoIdeaSchema>;
export type AiVideoIdea = typeof aiVideoIdeas.$inferSelect;

export const maintenanceConfig = pgTable("maintenance_config", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  whatsappSenderNumber: text("whatsapp_sender_number").default("+56953657460"),
  humanContactNumber: text("human_contact_number").default("+56 9 6251 1821"),
  paymentDueDay: integer("payment_due_day").default(5),
  bankName: text("bank_name").default("Mercado Pago"),
  accountType: text("account_type").default("Vista"),
  accountNumber: text("account_number").default("1041474795"),
  bankRut: text("bank_rut").default("78.042.968-2"),
  bankEmail: text("bank_email"),
  lateFeePct: text("late_fee_pct").default("1.5"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertMaintenanceConfigSchema = createInsertSchema(maintenanceConfig).omit({ id: true, updatedAt: true });
export type InsertMaintenanceConfig = z.infer<typeof insertMaintenanceConfigSchema>;
export type MaintenanceConfig = typeof maintenanceConfig.$inferSelect;

export const webAuditTokens = pgTable("web_audit_tokens", {
  id: serial("id").primaryKey(),
  token: text("token").notNull().unique(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  url: text("url").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const webAuditReports = pgTable("web_audit_reports", {
  id: serial("id").primaryKey(),
  reportToken: text("report_token").notNull().unique(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  url: text("url").notNull(),
  scores: jsonb("scores").notNull(),
  metrics: jsonb("metrics").notNull(),
  opportunities: jsonb("opportunities").notNull(),
  diagnostics: jsonb("diagnostics").notNull(),
  passedAudits: jsonb("passed_audits").notNull(),
  categoryBreakdowns: jsonb("category_breakdowns").notNull(),
  geminiAnalysis: text("gemini_analysis"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const jobApplications = pgTable("job_applications", {
  id: serial("id").primaryKey(),
  position: text("position").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  city: text("city"),
  linkedin: text("linkedin"),
  experience: text("experience"),
  motivation: text("motivation"),
  documentUrl: text("document_url"),
  quizScore: integer("quiz_score"),
  quizAnswers: text("quiz_answers"),
  status: text("status").default("pending").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertJobApplicationSchema = createInsertSchema(jobApplications).omit({ id: true, createdAt: true, status: true });
export type InsertJobApplication = z.infer<typeof insertJobApplicationSchema>;
export type JobApplication = typeof jobApplications.$inferSelect;

export const deckTokens = pgTable("deck_tokens", {
  id: serial("id").primaryKey(),
  token: varchar("token").notNull().unique(),
  label: text("label"),
  active: boolean("active").default(true).notNull(),
  viewCount: integer("view_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at"),
});

export type DeckToken = typeof deckTokens.$inferSelect;

export const addonStatusEnum = pgEnum("addon_status", ["DRAFT", "SENT", "APPROVED", "REJECTED"]);

export const projectAddons = pgTable("project_addons", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => projects.id).notNull(),
  title: text("title").notNull(),
  description: text("description"),
  subtotal: integer("subtotal").default(0).notNull(),
  iva: integer("iva").default(0).notNull(),
  total: integer("total").default(0).notNull(),
  hasIVA: integer("has_iva").default(1).notNull(),
  contractContent: text("contract_content"),
  status: addonStatusEnum("status").default("DRAFT").notNull(),
  tokenUrl: text("token_url").unique(),
  clientNote: text("client_note"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  respondedAt: timestamp("responded_at"),
  paidAt: timestamp("paid_at"),
});

export const projectAddonItems = pgTable("project_addon_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  addonId: varchar("addon_id").references(() => projectAddons.id).notNull(),
  serviceId: varchar("service_id").references(() => services.id),
  name: text("name").notNull(),
  description: text("description"),
  quantity: integer("quantity").default(1).notNull(),
  unitPrice: integer("unit_price").notNull(),
  total: integer("total").notNull(),
});

export const insertProjectAddonSchema = createInsertSchema(projectAddons).omit({ id: true, createdAt: true, respondedAt: true, tokenUrl: true, paidAt: true });
export type InsertProjectAddon = z.infer<typeof insertProjectAddonSchema>;
export type ProjectAddon = typeof projectAddons.$inferSelect;

export const insertProjectAddonItemSchema = createInsertSchema(projectAddonItems).omit({ id: true });
export type InsertProjectAddonItem = z.infer<typeof insertProjectAddonItemSchema>;

// ─── Linktree propio ────────────────────────────────────────────────────────
export const linktreeLinks = pgTable("linktree_links", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  subtitle: text("subtitle"),
  url: text("url").notNull(),
  platform: text("platform").notNull().default("link"),
  active: boolean("active").notNull().default(true),
  order: integer("order").notNull().default(0),
  clickCount: integer("click_count").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertLinktreeLinkSchema = createInsertSchema(linktreeLinks).omit({ id: true, createdAt: true });
export type InsertLinktreeLink = z.infer<typeof insertLinktreeLinkSchema>;
export type LinktreeLink = typeof linktreeLinks.$inferSelect;

export const linktreeProfile = pgTable("linktree_profile", {
  id: integer("id").primaryKey().default(1),
  name: text("name").notNull().default("WebMaker"),
  tagline: text("tagline").notNull().default("Agencia de Desarrollo Web y Software"),
  badge: text("badge").notNull().default("LATAM · Desde 2024"),
  websiteUrl: text("website_url").notNull().default("https://webmakerlatam.com"),
  websiteLabel: text("website_label").notNull().default("webmakerlatam.com"),
  websiteTitle: text("website_title").notNull().default("Visita nuestro sitio web"),
  videoUrl: text("video_url"),
  videoTitle: text("video_title"),
  closingTitle: text("closing_title").notNull().default("Construimos lo que otros no saben cómo hacer."),
  closingText: text("closing_text").notNull().default("Si tienes una idea, escríbenos. Cada gran proyecto comenzó con una conversación."),
});
export type LinktreeProfile = typeof linktreeProfile.$inferSelect;

export type ProjectAddonItem = typeof projectAddonItems.$inferSelect;

// Quick Reply Templates — respuestas rápidas con placeholders {{name}}, {{firstName}}, {{company}}, {{service}}, {{lucasPhone}}
export const quickReplyTemplates = pgTable("quick_reply_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  category: text("category").notNull().default("lead_response"),
  channel: text("channel").notNull().default("both"),
  body: text("body").notNull(),
  shortcut: text("shortcut"),
  usageCount: integer("usage_count").default(0).notNull(),
  isActive: integer("is_active").default(1).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertQuickReplyTemplateSchema = createInsertSchema(quickReplyTemplates).omit({
  id: true, createdAt: true, updatedAt: true, usageCount: true,
});
export type InsertQuickReplyTemplate = z.infer<typeof insertQuickReplyTemplateSchema>;
export type QuickReplyTemplate = typeof quickReplyTemplates.$inferSelect;

// Company Settings (singleton row used as source of truth for company info & IVA)
export const companySettings = pgTable("company_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyName: text("company_name").notNull().default("WebMaker"),
  email: text("email").notNull().default("webmakerlatam@gmail.com"),
  phone: text("phone").notNull().default("+56 9 6566 2698"),
  whatsapp: text("whatsapp").notNull().default("+56 9 6566 2698"),
  address: text("address").notNull().default("Los Andes, Chile"),
  ivaRate: integer("iva_rate").notNull().default(19),
  emailNotifications: integer("email_notifications").notNull().default(1),
  whatsappNotifications: integer("whatsapp_notifications").notNull().default(1),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertCompanySettingsSchema = createInsertSchema(companySettings).omit({ id: true, updatedAt: true });
export type InsertCompanySettings = z.infer<typeof insertCompanySettingsSchema>;
export type CompanySettings = typeof companySettings.$inferSelect;

// ===== SEO AUTOMATION (GPT-5) =====
// Geo-locations LATAM (countries + cities) for auto-generated landing pages
export const seoLocations = pgTable("seo_locations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  slug: text("slug").unique().notNull(), // chile, chile-los-andes, peru-lima
  name: text("name").notNull(), // "Los Andes"
  country: text("country").notNull(), // Chile, Argentina, Perú, etc.
  region: text("region"), // Valparaíso, etc. (optional)
  isCity: integer("is_city").default(0).notNull(), // 1 = ciudad, 0 = país
  population: integer("population"), // approximate
  priority: integer("priority").default(50).notNull(), // 1-100, higher = generate first
  isActive: integer("is_active").default(1).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertSeoLocationSchema = createInsertSchema(seoLocations).omit({ id: true, createdAt: true });
export type InsertSeoLocation = z.infer<typeof insertSeoLocationSchema>;
export type SeoLocation = typeof seoLocations.$inferSelect;

// Auto-generated SEO landing pages (service x location)
export const seoLandingPages = pgTable("seo_landing_pages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  slug: text("slug").unique().notNull(), // diseno-web-los-andes
  service: text("service").notNull(), // diseno-web, sistema-erp, app-movil, etc.
  serviceLabel: text("service_label").notNull(), // "Diseño Web"
  locationId: varchar("location_id").references(() => seoLocations.id),
  locationName: text("location_name").notNull(), // "Los Andes"
  country: text("country").notNull(), // Chile
  metaTitle: text("meta_title").notNull(),
  metaDescription: text("meta_description").notNull(),
  h1: text("h1").notNull(),
  introHtml: text("intro_html").notNull(),
  bodyHtml: text("body_html").notNull(), // long-form SEO body
  faqJson: text("faq_json").notNull().default("[]"), // [{q,a}]
  ctaText: text("cta_text").notNull().default("Cotizar ahora"),
  keywords: text("keywords").array().default(sql`ARRAY[]::text[]`).notNull(),
  isPublished: integer("is_published").default(1).notNull(),
  viewCount: integer("view_count").default(0).notNull(),
  generatedBy: text("generated_by").default("gpt-5").notNull(), // gpt-5 | manual
  publishedAt: timestamp("published_at").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertSeoLandingPageSchema = createInsertSchema(seoLandingPages).omit({ id: true, createdAt: true, viewCount: true });
export type InsertSeoLandingPage = z.infer<typeof insertSeoLandingPageSchema>;
export type SeoLandingPage = typeof seoLandingPages.$inferSelect;

// Generation log: report of what GPT-5 did each day
export const seoGenerationLogs = pgTable("seo_generation_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(), // "blog" | "geo-landing"
  status: text("status").notNull(), // "success" | "skipped" | "error"
  itemSlug: text("item_slug"), // slug of created article/landing
  itemTitle: text("item_title"),
  message: text("message"),
  tokensUsed: integer("tokens_used"),
  triggeredBy: text("triggered_by").default("cron").notNull(), // cron | manual
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertSeoGenerationLogSchema = createInsertSchema(seoGenerationLogs).omit({ id: true, createdAt: true });
export type InsertSeoGenerationLog = z.infer<typeof insertSeoGenerationLogSchema>;
export type SeoGenerationLog = typeof seoGenerationLogs.$inferSelect;

// =============================================================================
// TIENDA ONLINE — Sprint 1 (carrito + checkout MercadoPago)
// =============================================================================

export const orderStatusEnum = pgEnum("order_status", [
  "PENDING",
  "PAYMENT_PENDING",
  "PAID",
  "INTAKE_DONE",
  "CANCELLED",
  "REFUNDED",
]);

export const paymentStatusEnum = pgEnum("payment_status", [
  "PENDING",
  "APPROVED",
  "REJECTED",
  "REFUNDED",
  "IN_PROCESS",
]);

// NOTA: la tabla `coupons` ya existe arriba (línea ~505) para referidos +
// promociones. La tienda v1 reutiliza esa tabla marcando `isPromotion=1`.
// Mapeo: PERCENTAGE → discountPercent>0; FIXED → discountAmount>0.

// Órdenes de compra (1 por intento de checkout)
export const orders = pgTable("orders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orderNumber: text("order_number").notNull().unique(),
  status: orderStatusEnum("status").default("PENDING").notNull(),

  // Datos de contacto
  customerEmail: text("customer_email").notNull(),
  customerName: text("customer_name").notNull(),
  customerPhone: text("customer_phone"),

  // Datos fiscales (para emisión manual de boleta/factura)
  billingRut: text("billing_rut").notNull(),
  billingRazonSocial: text("billing_razon_social"),
  billingAddress: text("billing_address"),
  billingGiro: text("billing_giro"),
  billingComuna: text("billing_comuna"),
  billingCiudad: text("billing_ciudad"),

  // Montos (CLP)
  subtotalNeto: integer("subtotal_neto").notNull(),
  couponId: varchar("coupon_id").references(() => coupons.id),
  couponCode: text("coupon_code"),
  discountAmount: integer("discount_amount").default(0).notNull(),
  ivaRate: integer("iva_rate").default(19).notNull(),
  ivaAmount: integer("iva_amount").notNull(),
  totalAmount: integer("total_amount").notNull(),

  // MercadoPago
  mpPreferenceId: text("mp_preference_id"),
  mpInitPoint: text("mp_init_point"),

  // Atribución / vínculos
  source: text("source"),
  clientId: varchar("client_id").references(() => clients.id),
  termsAcceptedAt: timestamp("terms_accepted_at").notNull(),

  // Lifecycle
  expiresAt: timestamp("expires_at").notNull(),
  paidAt: timestamp("paid_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),

  // Token público para consultar la orden (evita IDOR por orderNumber predecible)
  accessToken: text("access_token").unique(),
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  createdAt: true,
  paidAt: true,
  mpPreferenceId: true,
  mpInitPoint: true,
  clientId: true,
  accessToken: true,
});
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof orders.$inferSelect;

// Items por orden (snapshot de precio en el momento del checkout)
export const orderItems = pgTable("order_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orderId: varchar("order_id").references(() => orders.id, { onDelete: "cascade" }).notNull(),
  subserviceId: text("subservice_id").notNull(),
  tierKey: text("tier_key").notNull(),
  productName: text("product_name").notNull(),
  unitPriceNeto: integer("unit_price_neto").notNull(),
  quantity: integer("quantity").default(1).notNull(),
  lineTotal: integer("line_total").notNull(),
});

export const insertOrderItemSchema = createInsertSchema(orderItems).omit({ id: true });
export type InsertOrderItem = z.infer<typeof insertOrderItemSchema>;
export type OrderItem = typeof orderItems.$inferSelect;

// Pagos asociados a una orden (1:N para soportar reintentos y reembolsos)
export const orderPayments = pgTable("order_payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orderId: varchar("order_id").references(() => orders.id).notNull(),
  mpPaymentId: text("mp_payment_id").notNull().unique(),
  mpStatus: paymentStatusEnum("mp_status").notNull(),
  mpStatusDetail: text("mp_status_detail"),
  amount: integer("amount").notNull(),
  paymentMethod: text("payment_method"),
  rawPayload: jsonb("raw_payload"),
  receivedAt: timestamp("received_at").defaultNow().notNull(),
});

export const insertOrderPaymentSchema = createInsertSchema(orderPayments).omit({ id: true, receivedAt: true });
export type InsertOrderPayment = z.infer<typeof insertOrderPaymentSchema>;
export type OrderPayment = typeof orderPayments.$inferSelect;

// Brief / intake post-pago (en /checkout/success)
export const orderIntakes = pgTable("order_intakes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orderId: varchar("order_id").references(() => orders.id).notNull().unique(),
  brandName: text("brand_name"),
  brandReferences: text("brand_references"),
  assetsUrl: text("assets_url"),
  preferredContact: text("preferred_contact"),
  preferredKickoffDate: timestamp("preferred_kickoff_date"),
  notes: text("notes"),
  submittedAt: timestamp("submitted_at").defaultNow().notNull(),
});

export const insertOrderIntakeSchema = createInsertSchema(orderIntakes).omit({ id: true, submittedAt: true });
export type InsertOrderIntake = z.infer<typeof insertOrderIntakeSchema>;
export type OrderIntake = typeof orderIntakes.$inferSelect;

// Carritos abandonados (email capture temprano en /checkout)
export const abandonedCheckouts = pgTable("abandoned_checkouts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull(),
  cartSnapshot: jsonb("cart_snapshot").notNull(),
  estimatedTotal: integer("estimated_total"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAbandonedCheckoutSchema = createInsertSchema(abandonedCheckouts).omit({ id: true, createdAt: true });
export type InsertAbandonedCheckout = z.infer<typeof insertAbandonedCheckoutSchema>;
export type AbandonedCheckout = typeof abandonedCheckouts.$inferSelect;
