# export-admin-sections

Exportación de componentes de `/admin/proposal-builder` y `/admin/projects`
del proyecto **webmakerlatam.com** para uso en el panel externo **admin.webmakerlatam.com**.

> **Este proyecto sigue siendo el dueño de los datos y del esquema.**
> El panel externo NO debe conectarse directamente a la base de datos;
> consume todo a través de `/api/service/` (ver §3 abajo).

---

## 1. Archivos copiados y dónde ubicarlos en el proyecto destino

| Archivo en esta carpeta | Ruta de destino en admin.webmakerlatam.com |
|---|---|
| `client/src/pages/proposal-builder.tsx` | `client/src/pages/proposal-builder.tsx` |
| `client/src/pages/proposals.tsx` | `client/src/pages/proposals.tsx` |
| `client/src/pages/proposal-details.tsx` | `client/src/pages/proposal-details.tsx` |
| `client/src/pages/projects.tsx` | `client/src/pages/projects.tsx` |
| `client/src/pages/project-details.tsx` | `client/src/pages/project-details.tsx` |
| `client/src/hooks/use-toast.ts` | `client/src/hooks/use-toast.ts` |
| `client/src/hooks/use-upload.ts` | `client/src/hooks/use-upload.ts` |
| `client/src/lib/queryClient.ts` | `client/src/lib/queryClient.ts` |
| `client/src/lib/utils.ts` | `client/src/lib/utils.ts` |
| `client/src/components/ui/card.tsx` | `client/src/components/ui/card.tsx` |
| `client/src/components/ui/button.tsx` | `client/src/components/ui/button.tsx` |
| `client/src/components/ui/input.tsx` | `client/src/components/ui/input.tsx` |
| `client/src/components/ui/textarea.tsx` | `client/src/components/ui/textarea.tsx` |
| `client/src/components/ui/badge.tsx` | `client/src/components/ui/badge.tsx` |
| `client/src/components/ui/skeleton.tsx` | `client/src/components/ui/skeleton.tsx` |
| `client/src/components/ui/select.tsx` | `client/src/components/ui/select.tsx` |
| `client/src/components/ui/dialog.tsx` | `client/src/components/ui/dialog.tsx` |
| `client/src/components/ui/form.tsx` | `client/src/components/ui/form.tsx` |
| `client/src/components/ui/switch.tsx` | `client/src/components/ui/switch.tsx` |
| `client/src/components/ui/label.tsx` | `client/src/components/ui/label.tsx` |
| `client/src/components/ui/checkbox.tsx` | `client/src/components/ui/checkbox.tsx` |
| `client/src/components/ui/tabs.tsx` | `client/src/components/ui/tabs.tsx` |
| `client/src/components/ui/collapsible.tsx` | `client/src/components/ui/collapsible.tsx` |
| `client/src/components/ui/scroll-area.tsx` | `client/src/components/ui/scroll-area.tsx` |
| `client/src/components/ui/popover.tsx` | `client/src/components/ui/popover.tsx` |
| `client/src/components/ui/tooltip.tsx` | `client/src/components/ui/tooltip.tsx` |
| `client/src/components/ui/progress.tsx` | `client/src/components/ui/progress.tsx` |
| `client/src/components/ui/alert-dialog.tsx` | `client/src/components/ui/alert-dialog.tsx` |
| `shared/schema.ts` | `shared/schema.ts` |

### Pasos post-copia en el proyecto destino

1. Ajusta los imports: los componentes usan alias `@/` (Vite) y `@shared/`. Configura los mismos alias en `vite.config.ts` y `tsconfig.json`.
2. En `queryClient.ts`, cambia la `baseUrl` para que apunte a `https://webmakerlatam.com/api/service/` (o usa una variable de entorno `VITE_API_BASE`).
3. Agrega el header `X-Service-Key: <valor>` en el helper `apiRequest`. **Nunca expongas este valor en el bundle del browser**; haz las llamadas server-side (Node.js/Next.js API routes, etc.) o usa un proxy BFF.
4. Instala las mismas dependencias (ver §e de EXPORT_SPEC.md).

---

## 2. Consideraciones de adaptación

- Los componentes usan `wouter` para navegación. Si el proyecto destino usa React Router u otro, reemplaza los imports de `useLocation`, `useRoute`, `Link`.
- El admin shell (sidebar, topbar, mobile-nav) **no está incluido**: pertenece al panel original. El proyecto destino debe proveer su propio layout.
- La autenticación de sesión admin original (`req.session.adminUser`) **no funciona** en el panel externo. Las rutas `/api/service/` usan `X-Service-Key`; adapta `apiRequest` en consecuencia.
- `use-upload.ts` usa el endpoint de object-storage de este proyecto. Deberás reapuntarlo o proveer tu propio endpoint de subida.

---

## 3. Rutas de API de servicio (servidor-a-servidor)

Todas las rutas están bajo `https://webmakerlatam.com/api/service/`.

**Autenticación**: header `X-Service-Key: <SERVICE_API_KEY>`.
**Rate limit**: 120 requests/minuto por clave.
**CORS**: deshabilitado (solo servidor-a-servidor).

### Propuestas

| Método | Ruta | Descripción |
|---|---|---|
| GET | /api/service/proposals | Lista todas las propuestas |
| GET | /api/service/proposals/:id | Propuesta + ítems |
| POST | /api/service/proposals | Crear propuesta |
| PATCH | /api/service/proposals/:id | Actualizar propuesta |
| DELETE | /api/service/proposals/:id | Eliminar propuesta |
| POST | /api/service/proposals/:id/generate-token | Generar tokenUrl |
| GET | /api/service/proposal-items/:proposalId | Ítems de una propuesta |
| POST | /api/service/proposal-items | Crear ítem |
| DELETE | /api/service/proposals/:id/items | Eliminar todos los ítems |

### Proyectos

| Método | Ruta | Descripción |
|---|---|---|
| GET | /api/service/projects | Lista todos los proyectos |
| GET | /api/service/projects/:id | Proyecto + tareas |
| PATCH | /api/service/projects/:id | Actualizar proyecto |
| DELETE | /api/service/projects/:id | Eliminar proyecto |
| GET | /api/service/projects/:projectId/logs | Bitácora |
| POST | /api/service/projects/:projectId/logs | Agregar entrada de bitácora |
| DELETE | /api/service/project-logs/:id | Eliminar entrada |
| GET | /api/service/projects/:projectId/payments | Pagos del proyecto |
| POST | /api/service/projects/:projectId/payments | Registrar pago |
| DELETE | /api/service/payments/:id | Eliminar pago |

### Datos de apoyo (solo lectura)

| Método | Ruta | Descripción |
|---|---|---|
| GET | /api/service/clients | Lista clientes |
| POST | /api/service/clients | Crear cliente |
| GET | /api/service/services | Catálogo de servicios |
| GET | /api/service/developers | Lista de developers (sin password_hash) |
