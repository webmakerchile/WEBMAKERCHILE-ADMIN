# EXPORT_SPEC.md
> Generado automáticamente el 2026-08-07 para las secciones /admin/proposal-builder y /admin/projects.
> Este proyecto (webmakerlatam.com) sigue siendo el **dueño de los datos y del esquema**.
> El panel externo (admin.webmakerlatam.com) consume los datos vía `/api/service/`.

---

## a) Archivos de componente

### /admin/proposal-builder · /admin/proposals · /admin/proposals/:id

| Ruta completa | Descripción |
|---|---|
| `client/src/pages/proposal-builder.tsx` | Página principal (2 492 líneas). Contiene internamente los sub-componentes `ClientSearchSelect`, `ServiceCard`, `ProposalItemRow` y `NewClientDialog` (no están en archivos separados). |
| `client/src/pages/proposals.tsx` | Lista de propuestas del admin. |
| `client/src/pages/proposal-details.tsx` | Vista de detalle de una propuesta (solo lectura). |

**UI compartida usada por proposal-builder:**

| Ruta completa |
|---|
| `client/src/components/ui/card.tsx` |
| `client/src/components/ui/button.tsx` |
| `client/src/components/ui/input.tsx` |
| `client/src/components/ui/textarea.tsx` |
| `client/src/components/ui/badge.tsx` |
| `client/src/components/ui/skeleton.tsx` |
| `client/src/components/ui/select.tsx` |
| `client/src/components/ui/dialog.tsx` |
| `client/src/components/ui/form.tsx` |
| `client/src/components/ui/switch.tsx` |
| `client/src/components/ui/label.tsx` |
| `client/src/components/ui/checkbox.tsx` |
| `client/src/components/ui/tabs.tsx` |
| `client/src/components/ui/collapsible.tsx` |
| `client/src/components/ui/scroll-area.tsx` |
| `client/src/components/ui/popover.tsx` |
| `client/src/components/ui/tooltip.tsx` |
| `client/src/components/ui/progress.tsx` |
| `client/src/components/ui/alert-dialog.tsx` |
| `client/src/components/admin-shell-sidebar.tsx` |
| `client/src/components/admin-shell-topbar.tsx` |
| `client/src/components/mobile-nav.tsx` |

**Hooks y utilidades:**

| Ruta completa |
|---|
| `client/src/hooks/use-toast.ts` |
| `client/src/hooks/use-upload.ts` |
| `client/src/lib/queryClient.ts` |
| `client/src/lib/utils.ts` |
| `client/src/app-routes.tsx` (routeo: líneas 32-34, 132-135) |

**Tipos compartidos:**

| Ruta completa |
|---|
| `shared/schema.ts` (tipos: `Service`, `Client`, `ProposalItem`, `AgreementTemplate`, `ServiceAgreement`, `CompanySettings`, `Proposal`, `Coupon`) |

---

### /admin/projects · /admin/projects/:id

| Ruta completa | Descripción |
|---|---|
| `client/src/pages/projects.tsx` | Lista de proyectos del admin. |
| `client/src/pages/project-details.tsx` | Vista de detalle con bitácora, pagos, addons y tareas. |

**UI compartida usada por projects/project-details:**

| Ruta completa |
|---|
| `client/src/components/ui/card.tsx` |
| `client/src/components/ui/button.tsx` |
| `client/src/components/ui/badge.tsx` |
| `client/src/components/ui/skeleton.tsx` |
| `client/src/components/ui/input.tsx` |
| `client/src/components/ui/progress.tsx` |
| `client/src/components/ui/textarea.tsx` |
| `client/src/components/ui/label.tsx` |
| `client/src/components/ui/select.tsx` |
| `client/src/components/ui/alert-dialog.tsx` |
| `client/src/components/ui/tooltip.tsx` |
| `client/src/components/ui/scroll-area.tsx` |
| `client/src/components/ui/collapsible.tsx` |

**Hooks y utilidades:**

| Ruta completa |
|---|
| `client/src/hooks/use-toast.ts` |
| `client/src/hooks/use-upload.ts` |
| `client/src/lib/queryClient.ts` |
| `client/src/lib/utils.ts` |

**Tipos compartidos:**

| Ruta completa |
|---|
| `shared/schema.ts` (tipos: `Project`, `Client`, `ProjectLog`, `Payment`, `Developer`, `ProjectAddon`, `ProjectAddonItem`) |

---

## b) Esquema de datos (Drizzle / PostgreSQL)

> Todos los IDs son `varchar` con `gen_random_uuid()` como default.
> Los valores monetarios son `integer` (pesos chilenos enteros, sin decimales).

### Enums

```sql
proposal_status:   DRAFT | SENT | VIEWED | APPROVED | REJECTED | EXPIRED
project_status:    MOCKUP | DEVELOPMENT | QA | DELIVERY | COMPLETED
payment_modality:  STANDARD | MILESTONES | FULL_ADVANCE | INSTALLMENTS | CUSTOM
maintenance_type:  NONE | TO_BE_DEFINED | CUSTOM
agreement_status:  DRAFT | PENDING_SIGNATURE | SIGNED | EXPIRED
agreement_template_type: LANDING_PAGE | WEBSITE | ECOMMERCE | WEB_APP | MOBILE_APP | CUSTOM
signature_type:    DRAWN | UPLOAD | TYPED
addon_status:      DRAFT | SENT | APPROVED | REJECTED
payment_method:    TRANSFERENCIA | ... (NO ENCONTRADO en lectura directa, valor default "TRANSFERENCIA")
```

---

### `clients`

| Columna | Tipo | Nulo | Default |
|---|---|---|---|
| id | varchar PK | NO | gen_random_uuid() |
| company_name | text | NO | — |
| rut | text | SÍ | null |
| billing_rut | text | SÍ | null |
| contact_name | text | SÍ | null |
| contact_email | text | SÍ | null |
| contact_phone | text | SÍ | null |
| address | text | SÍ | null |
| closer_id | varchar FK→developers.id | SÍ | null |
| created_at | timestamp | NO | now() |

---

### `services`

| Columna | Tipo | Nulo | Default |
|---|---|---|---|
| id | varchar PK | NO | gen_random_uuid() |
| name | text | NO | — |
| description | text | SÍ | null |
| base_price | integer | NO | — |
| cost_price | integer | NO | 0 |
| is_customizable | integer | SÍ | 0 |

---

### `proposals`

| Columna | Tipo | Nulo | Default |
|---|---|---|---|
| id | varchar PK | NO | gen_random_uuid() |
| client_id | varchar FK→clients.id | NO | — |
| status | proposal_status | NO | DRAFT |
| token_url | text UNIQUE | SÍ | null |
| subtotal | integer | NO | 0 |
| iva | integer | NO | 0 |
| total | integer | NO | 0 |
| has_iva | integer | NO | 1 |
| payment_modality | payment_modality | NO | STANDARD |
| installment_count | integer | SÍ | 3 |
| custom_payment_terms | text | SÍ | null |
| maintenance_type | maintenance_type | SÍ | NONE |
| monthly_maintenance | integer | NO | 0 |
| discount | integer | NO | 0 |
| coupon_id | varchar | SÍ | null |
| notes | text | SÍ | null |
| valid_until | timestamp | SÍ | null |
| include_contract | integer | NO | 1 |
| closer_id | varchar FK→developers.id | SÍ | null |
| margin_percent | integer | NO | 0 |
| margin_tier | text | NO | NONE |
| closer_commission_rate | integer | NO | 0 |
| closer_commission | integer | NO | 0 |
| created_at | timestamp | NO | now() |
| updated_at | timestamp | NO | now() |

---

### `proposal_items`

| Columna | Tipo | Nulo | Default |
|---|---|---|---|
| id | varchar PK | NO | gen_random_uuid() |
| proposal_id | varchar FK→proposals.id | NO | — |
| service_id | varchar FK→services.id | SÍ | null |
| name | text | NO | — |
| description | text | SÍ | null |
| quantity | integer | NO | 1 |
| unit_price | integer | NO | — |
| total | integer | NO | — |

---

### `developers`

| Columna | Tipo | Nulo | Default |
|---|---|---|---|
| id | varchar PK | NO | gen_random_uuid() |
| email | text UNIQUE | NO | — |
| password_hash | text | NO | — |
| name | text | NO | — |
| role | text | NO | developer |
| salary | integer | NO | 0 |
| is_active | integer | NO | 1 |
| created_at | timestamp | NO | now() |

---

### `projects`

| Columna | Tipo | Nulo | Default |
|---|---|---|---|
| id | varchar PK | NO | gen_random_uuid() |
| proposal_id | varchar FK→proposals.id | SÍ | null |
| client_id | varchar FK→clients.id | NO | — |
| name | text | NO | — |
| status | project_status | NO | MOCKUP |
| repository_url | text | SÍ | null |
| total_value | integer | NO | 0 |
| monthly_maintenance | integer | NO | 0 |
| assigned_developer_id | varchar FK→developers.id | SÍ | null |
| developer_payment | integer | NO | 0 |
| ai_cost_budget | integer | NO | 0 |
| deadline_days | integer | NO | 0 |
| deadline_start_date | timestamp | SÍ | null |
| drive_folder_url | text | SÍ | null |
| created_at | timestamp | NO | now() |

---

### `tasks` (checklist de proyecto)

| Columna | Tipo | Nulo | Default |
|---|---|---|---|
| id | varchar PK | NO | gen_random_uuid() |
| project_id | varchar FK→projects.id | NO | — |
| assigned_to | varchar FK→users.id | SÍ | null |
| proposal_item_id | varchar FK→proposal_items.id | SÍ | null |
| title | text | NO | — |
| description | text | SÍ | null |
| status | text | NO | pending |
| phase | project_status | NO | MOCKUP |
| weight | integer | NO | 1 |
| visible_to_client | integer | NO | 1 |
| freelancer_cost | integer | SÍ | 0 |
| completed_at | timestamp | SÍ | null |
| created_at | timestamp | NO | now() |

---

### `project_logs` (bitácora)

| Columna | Tipo | Nulo | Default |
|---|---|---|---|
| id | varchar PK | NO | gen_random_uuid() |
| project_id | varchar FK→projects.id | NO | — |
| title | text | NO | — |
| content | text | NO | — |
| phase | project_status | NO | MOCKUP |
| image_urls | text[] | SÍ | null |
| video_urls | text[] | SÍ | null |
| created_at | timestamp | NO | now() |

---

### `payments` (pagos de proyecto)

| Columna | Tipo | Nulo | Default |
|---|---|---|---|
| id | varchar PK | NO | gen_random_uuid() |
| project_id | varchar FK→projects.id | NO | — |
| amount | integer | NO | — |
| payment_method | payment_method enum | NO | TRANSFERENCIA |
| description | text | SÍ | null |
| has_iva | integer | NO | 0 |
| payment_date | timestamp | NO | now() |
| created_at | timestamp | NO | now() |

---

### `coupons`

| Columna | Tipo | Nulo | Default |
|---|---|---|---|
| id | varchar PK | NO | gen_random_uuid() |
| code | text UNIQUE | NO | — |
| name | text | SÍ | null |
| discount_percent | integer | NO | 10 |
| discount_amount | integer | SÍ | null |
| event_type | text | SÍ | null |
| is_promotion | integer | NO | 0 |
| max_uses | integer | SÍ | null |
| usage_count | integer | NO | 0 |
| issued_to_client_id | varchar FK→clients.id | SÍ | null |
| issued_from_project_id | varchar FK→projects.id | SÍ | null |
| used_by_client_id | varchar FK→clients.id | SÍ | null |
| used_on_proposal_id | varchar FK→proposals.id | SÍ | null |
| used_on_project_id | varchar FK→projects.id | SÍ | null |
| includes_free_meeting | integer | NO | 1 |
| is_used | integer | NO | 0 |
| original_document_url | text | SÍ | null |
| valid_from | timestamp | SÍ | null |
| expires_at | timestamp | SÍ | null |
| created_at | timestamp | NO | now() |

---

### `agreement_templates`

| Columna | Tipo | Nulo | Default |
|---|---|---|---|
| id | varchar PK | NO | gen_random_uuid() |
| name | text | NO | — |
| template_type | agreement_template_type | NO | — |
| content | text | NO | — |
| is_default | integer | NO | 0 |
| created_at | timestamp | NO | now() |
| updated_at | timestamp | NO | now() |

---

### `service_agreements`

| Columna | Tipo | Nulo | Default |
|---|---|---|---|
| id | varchar PK | NO | gen_random_uuid() |
| proposal_id | varchar FK→proposals.id | NO | — |
| template_id | varchar FK→agreement_templates.id | SÍ | null |
| token_url | text UNIQUE | NO | — |
| status | agreement_status | NO | DRAFT |
| client_company_name | text | NO | — |
| client_rut | text | SÍ | null |
| client_representative_name | text | NO | — |
| client_representative_rut | text | SÍ | null |
| content | text | NO | — |
| signed_at | timestamp | SÍ | null |
| signed_by_name | text | SÍ | null |
| signed_by_email | text | SÍ | null |
| signed_by_ip | text | SÍ | null |
| signature_type | signature_type | SÍ | null |
| signature_data | text | SÍ | null |
| signature_image_url | text | SÍ | null |
| signed_pdf_url | text | SÍ | null |
| valid_until | timestamp | SÍ | null |
| created_at | timestamp | NO | now() |
| updated_at | timestamp | NO | now() |

---

### `project_addons`

| Columna | Tipo | Nulo | Default |
|---|---|---|---|
| id | varchar PK | NO | gen_random_uuid() |
| project_id | varchar FK→projects.id | NO | — |
| title | text | NO | — |
| description | text | SÍ | null |
| subtotal | integer | NO | 0 |
| iva | integer | NO | 0 |
| total | integer | NO | 0 |
| has_iva | integer | NO | 1 |
| contract_content | text | SÍ | null |
| status | addon_status | NO | DRAFT |
| token_url | text UNIQUE | SÍ | null |
| client_note | text | SÍ | null |
| created_at | timestamp | NO | now() |
| responded_at | timestamp | SÍ | null |
| paid_at | timestamp | SÍ | null |

---

### `project_addon_items`

| Columna | Tipo | Nulo | Default |
|---|---|---|---|
| id | varchar PK | NO | gen_random_uuid() |
| addon_id | varchar FK→project_addons.id | NO | — |
| service_id | varchar FK→services.id | SÍ | null |
| name | text | NO | — |
| description | text | SÍ | null |
| quantity | integer | NO | 1 |
| unit_price | integer | NO | — |
| total | integer | NO | — |

---

### `company_settings` (singleton)

| Columna | Tipo | Nulo | Default |
|---|---|---|---|
| id | varchar PK | NO | gen_random_uuid() |
| company_name | text | NO | WebMaker |
| email | text | NO | webmakerlatam@gmail.com |
| phone | text | NO | +56 9 6566 2698 |
| whatsapp | text | NO | +56 9 6566 2698 |
| address | text | NO | Los Andes, Chile |
| iva_rate | integer | NO | 19 |
| email_notifications | integer | NO | 1 |
| whatsapp_notifications | integer | NO | 1 |
| updated_at | timestamp | NO | now() |

---

## c) Endpoints REST consumidos por las dos pantallas

### Proposals (/admin/proposal-builder)

| Método | Ruta | Query | Body | Respuesta |
|---|---|---|---|---|
| GET | /api/proposals | — | — | `Proposal[]` |
| GET | /api/proposals/:id | — | — | `Proposal & { items: ProposalItem[] }` |
| POST | /api/proposals | — | ver §d | `Proposal` 201 |
| PATCH | /api/proposals/:id | — | parcial §d | `Proposal` |
| DELETE | /api/proposals/:id | — | — | 204 |
| POST | /api/proposals/:id/generate-token | — | — | `Proposal` (con tokenUrl generado) |
| POST | /api/proposals/:id/calculate-commission | — | — | `{ marginPercent, marginTier, closerCommissionRate, closerCommission }` |
| GET | /api/proposal-items/:proposalId | — | — | `ProposalItem[]` |
| POST | /api/proposal-items | — | ver §d | `ProposalItem` 201 |
| DELETE | /api/proposals/:id/items | — | — | 204 |
| GET | /api/proposals/:id/pdf | — | — | `application/pdf` stream |
| GET | /api/clients | — | — | `Client[]` |
| POST | /api/clients | — | ver §d | `Client` 201 |
| GET | /api/services | — | — | `Service[]` |
| GET | /api/agreement-templates | — | — | `AgreementTemplate[]` |
| GET | /api/settings | — | — | `CompanySettings` |
| GET | /api/service-agreements/proposal/:proposalId | — | — | `ServiceAgreement \| null` |
| POST | /api/service-agreements | — | ver §d | `ServiceAgreement` |
| PATCH | /api/service-agreements/:id | — | parcial §d | `ServiceAgreement` |
| GET | /api/coupons/:couponId | — | — | `Coupon` |
| GET | /api/coupons/validate/:CODE | — | — | `{ valid: boolean, coupon?: Coupon }` |
| GET | /api/public/fx-rates | — | — | `{ ok, rates, source, fetchedAt }` (cache max-age=600s) |
| POST | /api/proposals/transcribe-audio | — | `{ audioData: string, mimeType?: string }` | `{ text }` |
| POST | /api/proposals/correct-items-ai | — | `{ items, correction }` | `{ items }` |
| POST | /api/proposals/generate-items-ai | — | `{ text, clientId? }` | `{ items }` |
| POST | /api/proposals/generate-whatsapp-message | — | `{ items, clientName, additionalContext? }` | `{ message }` |
| POST | /api/proposals/generate-cold-outreach | — | `{ items, clientName, companyName, additionalContext? }` | `{ message }` |
| POST | /api/proposals/generate-email-message | — | `{ items, clientName, companyName, additionalContext? }` | `{ subject, body }` |
| POST | /api/proposals/auto-fill-from-audio | — | `{ text }` | `{ items, paymentModality, installmentCount, customPaymentTerms, hasIva, maintenanceType, monthlyMaintenance, validUntil, notes, includeContract }` |
| POST | /api/service-agreements/generate-ai-content | — | `{ proposalId }` o `{ clientId, items, total, paymentModality, customPaymentTerms, installmentCount }` | secciones de contrato |
| POST | /api/service-agreements/correct-ai-content | — | `{ sections, correction }` | secciones corregidas |

### Projects (/admin/projects y /admin/projects/:id)

| Método | Ruta | Query | Body | Respuesta |
|---|---|---|---|---|
| GET | /api/projects | — | — | `Project[]` |
| GET | /api/projects/:id | — | — | `Project & { tasks: Task[] }` |
| PATCH | /api/projects/:id | — | campos parciales | `Project` |
| DELETE | /api/projects/:id | — | — | 204 |
| PATCH | /api/projects/:id/assign-developer | — | `{ developerId }` | `Project` |
| POST | /api/projects/:id/create-drive-folder | — | `{ force?: boolean }` | `{ folderUrl }` |
| GET | /api/projects/:projectId/logs | — | — | `ProjectLog[]` |
| POST | /api/projects/:projectId/logs | — | `{ title, content, phase?, imageUrls?, videoUrl? }` | `ProjectLog` 201 |
| DELETE | /api/project-logs/:id | — | — | 204 |
| GET | /api/projects/:projectId/payments | — | — | `{ payments: Payment[], totalPaid: number }` |
| POST | /api/projects/:projectId/payments | — | `{ amount, paymentMethod?, description?, paymentDate?, hasIVA? }` | `Payment` 201 |
| DELETE | /api/payments/:id | — | — | 204 |
| PATCH | /api/payments/:id | — | campos parciales | `Payment` |
| GET | /api/projects/:projectId/addons | — | — | `ProjectAddon[]` |
| POST | /api/projects/:projectId/addons | — | `{ title, description?, subtotal, iva, total, hasIVA?, contractContent? }` | `ProjectAddon` 201 |
| PATCH | /api/addons/:id/send | — | — | `ProjectAddon` |
| DELETE | /api/addons/:id | — | — | 204 |
| POST | /api/addons/:id/toggle-paid | — | — | `ProjectAddon` |
| GET | /api/developers | — | — | `Developer[]` (sin password_hash) |
| GET | /api/clients | — | — | `Client[]` |

---

## d) Validaciones Zod

### `insertProposalSchema` (generado por drizzle-zod de la tabla `proposals`)
Omite: `id`, `created_at`, `updated_at`. Todos los campos de la tabla son validables; los campos con default en DB son opcionales en Zod. Campos críticos:
```ts
{
  clientId: string (required),
  status?: "DRAFT"|"SENT"|"VIEWED"|"APPROVED"|"REJECTED"|"EXPIRED",
  subtotal?: number,
  iva?: number,
  total?: number,
  hasIVA?: number,
  paymentModality?: "STANDARD"|"MILESTONES"|"FULL_ADVANCE"|"INSTALLMENTS"|"CUSTOM",
  installmentCount?: number,
  customPaymentTerms?: string | null,
  maintenanceType?: "NONE"|"TO_BE_DEFINED"|"CUSTOM" | null,
  monthlyMaintenance?: number,
  discount?: number,
  couponId?: string | null,
  notes?: string | null,
  validUntil?: Date | null,   // el servidor convierte string ISO a Date
  includeContract?: number,
  closerId?: string | null,
}
```

### `insertProposalItemSchema`
```ts
{
  proposalId: string (required),
  serviceId?: string | null,
  name: string (required),
  description?: string | null,
  quantity?: number,
  unitPrice: number (required),
  total: number (required),
}
```

### `insertProjectSchema`
```ts
{
  proposalId?: string | null,
  clientId: string (required),
  name: string (required),
  status?: "MOCKUP"|"DEVELOPMENT"|"QA"|"DELIVERY"|"COMPLETED",
  repositoryUrl?: string | null,
  totalValue?: number,
  monthlyMaintenance?: number,
  assignedDeveloperId?: string | null,
  developerPayment?: number,
  aiCostBudget?: number,
  deadlineDays?: number,
  deadlineStartDate?: Date | null,
  driveFolderUrl?: string | null,
}
```

### `clientFormSchema` (definida inline en proposal-builder.tsx)
```ts
z.object({
  companyName: z.string().min(1),
  contactName: z.string().min(1),
  contactEmail: z.string().email().optional().or(z.literal("")),
  rut: z.string().optional(),
  contactPhone: z.string().optional(),
  address: z.string().optional(),
})
```

### `insertServiceAgreementSchema`
```ts
{
  proposalId: string (required),
  templateId?: string | null,
  // token_url se genera en el servidor
  status?: agreement_status,
  clientCompanyName: string (required),
  clientRut?: string | null,
  clientRepresentativeName: string (required),
  clientRepresentativeRut?: string | null,
  content: string (required),
  validUntil?: Date | null,
}
```

---

## e) Dependencias npm relevantes

| Paquete | Versión en package.json |
|---|---|
| react-hook-form | ^7.55.0 |
| @hookform/resolvers | ^3.10.0 |
| zod | ^3.25.76 |
| zod-validation-error | ^3.5.4 |
| @tanstack/react-query | ^5.60.5 |
| wouter | ^3.9.0 |
| lucide-react | ^0.453.0 |
| date-fns | ^3.6.0 |
| clsx | ^2.1.1 |
| tailwind-merge | ^2.6.0 |
| class-variance-authority | ^0.7.1 |
| drizzle-zod | ^0.7.1 |
| @radix-ui/react-dialog | ^1.1.7 |
| @radix-ui/react-select | ^2.1.7 |
| @radix-ui/react-tabs | ^1.1.4 |
| @radix-ui/react-collapsible | ^1.1.4 |
| @radix-ui/react-popover | ^1.1.7 |
| @radix-ui/react-scroll-area | ^1.2.4 |
| @radix-ui/react-switch | ^1.1.4 |
| @radix-ui/react-label | ^2.1.8 |
| @radix-ui/react-checkbox | ^1.1.5 |
| @radix-ui/react-toast | ^1.2.7 |
| @radix-ui/react-alert-dialog | ^1.1.7 |
| @radix-ui/react-tooltip | ^1.2.0 |
| @radix-ui/react-progress | ^1.1.3 |
| tailwindcss-animate | ^1.0.7 |

---

## f) Lógica de negocio no obvia

### Totales y IVA
- `subtotal` = suma de `total` de todos los `proposal_items` menos `discount`.
- `iva` = `subtotal * (companySettings.ivaRate / 100)` si `hasIVA === 1`, else `0`.
- `total` = `subtotal + iva`.
- Todos los montos se almacenan en **pesos chilenos enteros** (integer). Sin decimales.

### Descuentos y cupones
- `discount` es un monto fijo en CLP que se resta del subtotal bruto.
- Si hay `couponId`, el descuento puede derivar de `coupon.discountPercent` o `coupon.discountAmount`. La conversión es responsabilidad del frontend.
- Al aprobar una propuesta (PATCH status=APPROVED), si había cupón asociado, el servidor llama `storage.useCoupon()` y actualiza `coupon.usedOnProjectId`.

### Aprobación de propuesta → creación de proyecto (side-effect crítico)
Cuando `PATCH /api/proposals/:id` recibe `{ status: "APPROVED" }`, el servidor:
1. Recalcula la comisión del closer y la escribe en `proposals` (marginPercent, marginTier, closerCommissionRate, closerCommission).
2. Crea automáticamente un `Project` con `status=MOCKUP` y `totalValue=proposal.total`.
3. Genera un checklist de tareas (`tasks`) a partir de los `proposal_items`, asignando `phase` por keywords del nombre del ítem.
4. Aplica el cupón si existía.
5. Envía email de notificación al cliente vía Resend.

### Generación de token público
`POST /api/proposals/:id/generate-token` genera `crypto.randomUUID().replace(/-/g,'').slice(0,16).toUpperCase()` y lo guarda en `tokenUrl`. No hay numeración correlativa/folio.

### PDF
`GET /api/proposals/:id/pdf` genera el PDF en memoria con `PDFDocument` (A4) con branding WebMaker. El filename es `presupuesto-${proposal.tokenUrl || proposal.id.slice(0,8)}.pdf`.

### Moneda extranjera
`GET /api/public/fx-rates` retorna tasas de cambio con caché de 1 hora en servidor y `max-age=600` al browser. El builder muestra precios en USD/EUR convertidos pero los guarda siempre en CLP.

### Comisión del closer
Calculada por `calculateCloserCommission(items, servicesMap, subtotal, priorBaseSales)` (función interna en routes.ts). El margin_tier determina el porcentaje de comisión; se considera el historial de ventas al precio base del closer. **Lógica no duplicada en /api/service/**; el endpoint `POST /api/proposals/:id/calculate-commission` la expone.

### Email al aprobar
`sendProposalApprovedNotification` vía Resend; falla silenciosa (no aborta la request).

### Notificación al crear log de proyecto
`POST /api/projects/:projectId/logs` envía `sendProjectUpdateNotification` al email del cliente vía Resend; falla silenciosa.

### Coupon al completar proyecto
`PATCH /api/projects/:id` con `{ status: "COMPLETED" }` llama `storage.generateCouponForProject()` y crea una `completion_offer` automáticamente.

### Deadline
`PATCH /api/projects/:id` con `deadlineDays > 0` y valor diferente al anterior resetea `deadlineStartDate = new Date()`.

---

## g) Endpoints de /api/service/ (creados en esta exportación)

Ver sección §c del README de `/export-admin-sections/README.md` y la tabla completa en el chat de entrega.

---
*Fin del documento. Todo lo anterior proviene de lectura directa del código fuente. Nada inventado.*
