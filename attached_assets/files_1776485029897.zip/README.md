# 🦊 WebMakerLatam - Secciones Nuevas

Dos nuevos apartados para tu generador de contenido:
1. **Generador de Historias** (imágenes 9:16 con el zorro para stories)
2. **Generador de Descripciones Diarias** (texto + hashtags para 4 redes)

## 📦 Instalación en Replit

### 1. Instalar dependencias

```bash
npm install @google/genai @anthropic-ai/sdk @replit/database express cors
```

### 2. Configurar variables de entorno (Secrets en Replit)

En la pestaña **Secrets** de tu Replit, agrega:

- `GEMINI_API_KEY` → tu API key de Google Gemini
- `ANTHROPIC_API_KEY` → tu API key de Anthropic Claude

### 3. Copiar los archivos a tu proyecto

```
tu-proyecto/
├── backend/
│   ├── generarHistoria.js
│   ├── generarDescripciones.js
│   └── server.js (o integrar las rutas a tu server existente)
└── frontend/
    └── src/
        ├── GeneradorHistorias.jsx
        └── GeneradorDescripciones.jsx
```

### 4. Integrar las rutas en tu server.js existente

Si ya tienes un `server.js` para el generador de portadas, solo agrega:

```javascript
import {
  generarHistoriaHandler,
  listarHistoriasHandler,
} from "./generarHistoria.js";
import {
  generarDescripcionesHandler,
  listarDescripcionesHandler,
  eliminarDescripcionHandler,
} from "./generarDescripciones.js";

app.post("/api/historias/generar", generarHistoriaHandler);
app.get("/api/historias", listarHistoriasHandler);
app.post("/api/descripciones/generar", generarDescripcionesHandler);
app.get("/api/descripciones", listarDescripcionesHandler);
app.delete("/api/descripciones/:id", eliminarDescripcionHandler);
```

### 5. Integrar los componentes React en tu app

En tu router (React Router, Next.js, etc.):

```jsx
import GeneradorHistorias from "./GeneradorHistorias";
import GeneradorDescripciones from "./GeneradorDescripciones";

// En tu menú/navegación:
// /portadas      → Generador de Portadas (ya existente)
// /historias     → <GeneradorHistorias />
// /descripciones → <GeneradorDescripciones />
```

## 🎯 Endpoints de la API

### Historias

**POST** `/api/historias/generar`

```json
{
  "tipo_historia": "tip_tech | motivacional | comunidad",
  "concepto": "aprende git en 1 minuto",
  "pose_override": "(opcional) pose específica"
}
```

Respuesta:
```json
{
  "success": true,
  "data": {
    "id": "historia_1234567890",
    "imagen": "data:image/png;base64,...",
    "tipo_historia": "tip_tech",
    "concepto": "aprende git en 1 minuto",
    "fecha": "2026-04-17T..."
  }
}
```

**GET** `/api/historias` → lista todas las historias generadas

### Descripciones

**POST** `/api/descripciones/generar`

```json
{
  "tema": "Cómo usar async/await en JavaScript",
  "tipo_contenido": "tutorial | tip | reflexion | comunidad | lanzamiento",
  "redes": ["tiktok", "instagram", "youtube_shorts", "twitter"]
}
```

Respuesta:
```json
{
  "success": true,
  "data": {
    "id": "descripcion_1234567890",
    "fecha": "2026-04-17T...",
    "tema": "...",
    "tipo_contenido": "tutorial",
    "contenido": {
      "tiktok": { "descripcion": "...", "hashtags": "#..." },
      "instagram": { "descripcion": "...", "hashtags": "#..." },
      "youtube_shorts": { "descripcion": "...", "hashtags": "#..." },
      "twitter": { "post_completo": "..." }
    }
  }
}
```

**GET** `/api/descripciones` → lista todas las descripciones guardadas  
**DELETE** `/api/descripciones/:id` → elimina una descripción

## 🗓️ Automatización diaria (opcional)

Para generar descripciones **todos los días automáticamente** usa **Scheduled Deployments** de Replit:

1. Ve a tu Repl → **Deployments** → **Scheduled**
2. Cron: `0 8 * * *` (todos los días a las 8am)
3. Comando: un script que llame a tu endpoint con un tema rotativo

Ejemplo de script `scripts/generarDiario.js`:

```javascript
const TEMAS_SEMANA = {
  1: { tema: "Tip de productividad para devs", tipo: "tip" },       // Lunes
  2: { tema: "Herramienta recomendada de la semana", tipo: "tip" }, // Martes
  3: { tema: "Reflexión sobre el camino del dev", tipo: "reflexion" }, // Miércoles
  4: { tema: "Tutorial rápido de JavaScript", tipo: "tutorial" },   // Jueves
  5: { tema: "Motivación para cerrar la semana", tipo: "comunidad" }, // Viernes
  6: { tema: "Proyecto personal para el fin de semana", tipo: "tip" }, // Sábado
  0: { tema: "Recap de la semana en WebMaker", tipo: "comunidad" }, // Domingo
};

const hoy = new Date().getDay();
const { tema, tipo } = TEMAS_SEMANA[hoy];

fetch("https://tu-repl.repl.co/api/descripciones/generar", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    tema,
    tipo_contenido: tipo,
    redes: ["tiktok", "instagram", "youtube_shorts", "twitter"],
  }),
}).then(() => console.log("✅ Descripciones del día generadas"));
```

## 💰 Costos aproximados por generación

| Servicio | Costo estimado por uso |
|---|---|
| Gemini Imagen 4 (historia) | ~$0.04 USD por imagen |
| Claude Sonnet 4.5 (descripciones 4 redes) | ~$0.01 USD por generación |

**Si generas 1 historia + 1 set de descripciones diario durante 30 días: ~$1.50 USD/mes**

## 🎨 Flujo de trabajo sugerido

1. **Lunes 8am** → Generador automático crea descripciones del día
2. **Tú** → Revisas en el dashboard y ajustas si es necesario
3. **Generas historia** con el tipo que corresponda al contenido del día
4. **Descargas** la imagen y agregas texto overlay en Canva/Figma
5. **Publicas** en las 4 redes con el texto ya generado

## ✅ Checklist de integración

- [ ] Dependencias instaladas
- [ ] Variables de entorno configuradas
- [ ] Rutas del backend integradas
- [ ] Componentes React agregados al menú
- [ ] Test manual de `/api/historias/generar`
- [ ] Test manual de `/api/descripciones/generar`
- [ ] (Opcional) Scheduled deployment configurado
